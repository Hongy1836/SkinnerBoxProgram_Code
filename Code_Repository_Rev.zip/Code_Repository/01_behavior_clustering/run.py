from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score,calinski_harabasz_score,davies_bouldin_score,adjusted_rand_score

def run():
 f=pd.read_csv(SD1/'clustering_features.csv').set_index('animal').loc[AN];F=f[['early','late','auc','cv']].to_numpy();z=(F-F.mean(0))/F.std(0)
 km=KMeans(n_clusters=2,n_init=50,random_state=SEED).fit(z);high=np.argmax([F[km.labels_==g,1].mean() for g in [0,1]]);np.testing.assert_array_equal(km.labels_==high,Y)
 loo=[]
 for i in range(N):
  keep=np.arange(N)!=i;mu=F[keep].mean(0);sd=F[keep].std(0);k=KMeans(n_clusters=2,n_init=50,random_state=SEED).fit((F[keep]-mu)/sd);hi=np.argmax([F[keep][k.labels_==g,1].mean() for g in [0,1]]);loo.append(int(k.predict(((F[i]-mu)/sd)[None])[0]==hi))
 pd.DataFrame({'animal':AN,'group':Y,'loo_group':loo}).to_csv(OUT/'behavior_LOO.csv',index=False)
 rows=[]
 for k in range(1,9):
  model=KMeans(n_clusters=k,n_init=50,random_state=SEED).fit(z);row={'k':k,'inertia':model.inertia_}
  if k>1:row.update(silhouette_euclidean=silhouette_score(z,model.labels_),silhouette_sqeuclidean=silhouette_score(z,model.labels_,metric='sqeuclidean'),calinski_harabasz=calinski_harabasz_score(z,model.labels_),davies_bouldin=davies_bouldin_score(z,model.labels_))
  rows.append(row)
 pd.DataFrame(rows).to_csv(OUT/'cluster_diagnostics_recalculated.csv',index=False)
 # These diagnostic settings are explicit; original FigS1 ARI resampling settings are unavailable.
 rng=np.random.default_rng(SEED);rows=[]
 for repeat in range(500):
  tr=rng.integers(0,N,N);te=np.setdiff1d(np.arange(N),tr);mu=F[tr].mean(0);sd=F[tr].std(0);model=KMeans(n_clusters=2,n_init=50,random_state=SEED+repeat).fit((F[tr]-mu)/sd);hi=np.argmax([F[tr][model.labels_==g,1].mean() for g in [0,1]]);pred=model.predict((F[te]-mu)/sd)==hi
  for i,p in zip(te,pred):rows.append(dict(repeat=repeat,animal=AN[i],label=Y[i],prediction=int(p)))
 pd.DataFrame(rows).to_csv(OUT/'clustering_bootstrap_recalculated.csv',index=False)
 print('Fixed labels and LOO reconstructed; supplementary diagnostic recalculation stored separately.')
if __name__=='__main__':run()
