from pathlib import Path
import argparse,subprocess,sys
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--catalogue',action='store_true');p.add_argument('--figures',action='store_true');a=p.parse_args()
for module in ['01_behavior_clustering','02_stage_changes_NBS','03_continuous_associations','04_group_trajectories_and_baseline','05_nearest_centroid_classifiers']:
 subprocess.run([sys.executable,str(R/module/'run.py')],check=True)
if a.catalogue:subprocess.run([sys.executable,str(R/'04_group_trajectories_and_baseline/catalogue.py')],check=True)
subprocess.run([sys.executable,str(R/'03_continuous_associations/active_responses.py')],check=True)
if a.figures:subprocess.run([sys.executable,str(R/'06_figure_generation/run.py')],check=True)
