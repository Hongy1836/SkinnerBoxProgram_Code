from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
THRESH=np.array([0.,-.25,.25])
def inner_splits(tr,y,seed):
    # Joint strata when possible; otherwise group-only. No test labels accessed.
    labels=np.array([str(y[i])+'_'+BT[i] for i in tr])
    if min(np.unique(labels,return_counts=True)[1])<3:labels=y[tr]
    return [(tr[a],tr[b]) for a,b in StratifiedKFold(3,shuffle=True,random_state=seed).split(tr,labels)]

def performance_arrays(y,scores):
    # Input (n, candidates); output BA(candidate, threshold), pooled inner AUC.
    ba=np.array([(.5*((scores[y==1]>=t).mean(0)+(scores[y==0]<t).mean(0))) for t in THRESH]).T
    ranks=stats.rankdata(scores,axis=0);n1=y.sum();n0=len(y)-n1
    auc=(ranks[y==1].sum(0)-n1*(n1+1)/2)/(n1*n0)
    return ba,auc

def folds(scheme):
    if scheme=='B2toB1':return [(np.flatnonzero(BT=='B2'),np.flatnonzero(BT=='B1'),'B2toB1',SEED+900)]
    return [(np.flatnonzero(np.arange(N)!=i),np.array([i]),f'LOO_{i:02}',SEED+100+i) for i in range(N)]
def score(x,m,tr,te):
 C=np.c_[np.ones(N),m];coef=np.linalg.lstsq(C[tr],x[tr],rcond=None)[0];a=x[tr]-C[tr]@coef;b=x[te]-C[te]@coef
 m0=a[Y[tr]==0].mean();m1=a[Y[tr]==1].mean()
 return (b-(m0+m1)/2)*np.sign(m1-m0)/max(abs(m1-m0)/2,1e-8)
def run():
 models=[(a+'-'+b+' baseline','B',[a+'-'+b]) for a in ['ACC','PrL'] for b in ['NAc','DMS','DLS']]+[('DLS-M1-AI training change','dL',['DLS-M1','DLS-AI','M1-AI'])];rows=[]
 for name,ly,edges in models:
  x=XFC[ly][:,[EN.index(e) for e in edges]].mean(1)
  for scheme in ['LOO','B2toB1']:
   for tr,te,fold,seed in folds(scheme):
    inner=np.zeros(len(tr));pos={k:i for i,k in enumerate(tr)}
    for ia,ib in inner_splits(tr,Y,seed):inner[[pos[k] for k in ib]]=score(x,MOTION[ly],ia,ib)
    ba,_=performance_arrays(Y[tr],inner[:,None]);threshold=THRESH[np.argmax(ba[0])];s=score(x,MOTION[ly],tr,te)
    for k,val in zip(te,s):rows.append(dict(model=name,scheme=scheme,animal=AN[k],label=Y[k],prediction=int(val>=threshold),score=val,threshold=threshold))
 out=pd.DataFrame(rows);out.to_csv(OUT/'classifier_predictions.csv',index=False)
 ref=pd.read_csv(SD1/'classifier_individual_predictions.csv');m=out.merge(ref,on=['model','scheme','animal'],suffixes=('_run','_ref'),validate='one_to_one');assert len(m)==287
 np.testing.assert_allclose(m.score_run,m.score_ref,atol=1e-10);np.testing.assert_array_equal(m.prediction_run,m.prediction_ref)
 print('287 saved predictions reproduced from individual FC and FD values.')
if __name__=='__main__':run()
