from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *

def components(t,sgn):
 parent=list(range(len(NODES)))
 def root(a):
  while parent[a]!=a:a=parent[a]
  return a
 selected=np.flatnonzero(sgn*t>3)
 for j in selected:
  a,b=[NODES.index(x) for x in PAIRS[j]];parent[root(a)]=root(b)
 groups={}
 for j in selected:groups.setdefault(root(NODES.index(PAIRS[j][0])),[]).append(int(j))
 return sorted(groups.values(),key=len,reverse=True)
def run():
 rows=[];nbs=[]
 for a,b in [('L','B'),('S','L')]:
  X=stage.design(BD,FD[a]-FD[b]);D=E[a]-E[b];t,est,se=stage.hc2_t(D,X)
  p=stage.single_p(t,stage.boot_t(D,X,stage.multipliers(N,9999,3822434024)));crit=stats.t.ppf(.975,N-3)
  for j,e in enumerate(EN):rows.append(dict(contrast=a+'-'+b,edge=e,change=est[j],SE=se[j],CI_low=est[j]-crit*se[j],CI_high=est[j]+crit*se[j],P=p[j]))
  t0=stage.classic_t(D,X)[0];null=stage.boot_t(D,X,stage.multipliers(N,9999,47724983),stat=stage.classic_t)
  for sign in [1,-1]:
   comp=components(t0,sign);size=len(comp[0]) if comp else 0;nn=np.array([max(map(len,components(t,sign)),default=0) for t in null])
   nbs.append(dict(contrast=a+'-'+b,direction='increase' if sign==1 else 'decrease',size=size,edges=';'.join(EN[j] for j in comp[0]) if comp else '',P=(1+(nn>=size).sum())/10000))
 for name,rr in [('stage_edges78',rows),('stage_nbs',nbs)]:
  t=pd.DataFrame(rr);t.to_csv(OUT/(name+'.csv'),index=False);ref=pd.read_csv(ROOT/'Supplementary_Data_2'/(name+'.csv'))
  np.testing.assert_allclose(t.P,ref.P,atol=1e-12)
 print('Stage and NBS p values reproduced.')
if __name__=='__main__':run()
