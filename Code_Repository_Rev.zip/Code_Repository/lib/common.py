import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='1'
import sys,json,itertools,time
from pathlib import Path
import numpy as np,pandas as pd
from scipy import stats
import stage,interact
ROOT=Path(__file__).resolve().parents[2]
SD1=ROOT/'Supplementary_Data_1';OUT=Path(__file__).resolve().parents[1]/'outputs';OUT.mkdir(exist_ok=True)
SEED=20261014
fc=pd.read_csv(SD1/'functional_connectivity_93scans_78edges.csv');bh=pd.read_csv(SD1/'behavior_endpoint_catalogue.csv')
AN=fc[fc.phase=='B'].animal.to_numpy();BH=bh.set_index('animal').loc[AN];BT=BH.batch.to_numpy();BD=(BT=='B2').astype(float);Y=BH.group.to_numpy(int);N=len(Y)
EN=list(fc.columns[5:]);PAIRS=[tuple(e.split('-')) for e in EN];NODES=list(dict.fromkeys(n for p in PAIRS for n in p))
E={p:fc[fc.phase==p].set_index('animal').loc[AN,EN].to_numpy() for p in 'BLS'}
FD={p:fc[fc.phase==p].set_index('animal').loc[AN,'FD_mm'].to_numpy() for p in 'BLS'}
LAYERS=['B','L','S','dL','dS'];XFC=dict(E,dL=E['L']-E['B'],dS=E['S']-E['L']);MOTION=dict(FD,dL=FD['L']-FD['B'],dS=FD['S']-FD['L'])
LITERATURE={
 'Motivation4':['ACC','PrL','NAc','VTA'],
 'ActionValue3':['PrL','OrbB','DMS'],
 'MotorAction3':['DLS','M1','M2'],
 'Sensorimotor5':['DLS','M1','M2','S1','S2'],
 'FeedingDrive3':['NAc','VTA','LHA'],
 'Interoception2':['AI','LHA'],
 'MotivationInteroception6':['ACC','PrL','NAc','AI','VTA','LHA'],
 'ValueAction6':['PrL','OrbB','DMS','DLS','M1','M2'],
 'All13':NODES}
SUBSETS=[s for size in range(2,14) for s in itertools.combinations(NODES,size)]
NS=len(SUBSETS)
MEM=np.array([[a in s and b in s for a,b in PAIRS] for s in SUBSETS],float).T
W=MEM/MEM.sum(0)
SUBMETA=pd.DataFrame([dict(subset_id=j,n_roi=len(s),n_edges=len(s)*(len(s)-1)//2,rois=';'.join(s)) for j,s in enumerate(SUBSETS)])
LITID={k:next(i for i,s in enumerate(SUBSETS) if set(s)==set(v)) for k,v in LITERATURE.items()}

def group_design(layer,idx=None):
 if idx is None:idx=np.arange(N)
 return np.c_[Y[idx],np.ones(len(idx)),BD[idx],MOTION[layer][idx]]
def raw_ols(D,X):
 t,b,se=stage.hc2_t(np.asarray(D),X);df=len(X)-np.linalg.matrix_rank(X);crit=stats.t.ppf(.975,df)
 return dict(effect=b,SE=se,t=t,P_approx=2*stats.t.sf(abs(t),df),CI_low=b-crit*se,CI_high=b+crit*se)
def log(s):print(s,flush=True)
def savej(p,x):Path(p).write_text(json.dumps(x,default=lambda v:v.tolist() if hasattr(v,'tolist') else str(v),indent=2))
