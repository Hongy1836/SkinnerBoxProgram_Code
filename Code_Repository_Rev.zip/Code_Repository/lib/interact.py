"""rtlib.interact -- does the connectivity-behaviour relation change across phases? (H07/H08 and the Q5 map; EXEC section 3)

Stacked within-animal differences, rows 0..n-1 = L - B, rows n..2n-1 = S - B. Restricted design X0 = [1_L, 1_S, batch_c 1_L,
batch_c 1_S, dFD (one shared slope)]; full design X1 = X0 + [z 1_L, z 1_S] for a z-scored behaviour z. GLS with the
difference covariance Omega = [[2, 1], [1, 2]] (x) I (equivalent to animal fixed effects). The whitening keeps each animal's
two rows together, so animals are the clusters of the robust variance.
Statistics: (a) the cluster-robust (CR1) Wald statistic of gamma = (gamma_L, gamma_S) -- primary; (b) the homoscedastic F of
r3 (replay). Null: restricted fit + restricted residuals x one Rademacher multiplier per animal (both rows)."""
import numpy as np


class Interaction:
    def __init__(self, bc, dfd_L, dfd_S, Z):
        """bc: batch dummy (n,), dfd_L = FD_L - FD_B, dfd_S = FD_S - FD_B, Z (n, K) behaviours (z-scored inside)"""
        n = len(bc); self.n = n
        b = bc - bc.mean(); one, zero = np.ones(n), np.zeros(n)
        self.X0 = np.column_stack([np.concatenate([one, zero]), np.concatenate([zero, one]), np.concatenate([b, zero]),
                                   np.concatenate([zero, b]), np.concatenate([dfd_L, dfd_S])])
        Om = np.kron(np.array([[2.0, 1.0], [1.0, 2.0]]), np.eye(n))
        self.Wh = np.linalg.cholesky(np.linalg.inv(Om)).T
        self.Z = (Z - Z.mean(0)) / Z.std(0, ddof=1)
        self.K = Z.shape[1]
        X0w = self.Wh @ self.X0; self.M0 = np.eye(2 * n) - X0w @ np.linalg.pinv(X0w); self.P0w = np.linalg.pinv(X0w)
        self.A, self.M1, self.cr1 = [], [], []
        for k in range(self.K):
            z = self.Z[:, k]
            X1 = np.column_stack([self.X0, np.concatenate([z, zero]), np.concatenate([zero, z])]); X1w = self.Wh @ X1
            Bread = np.linalg.inv(X1w.T @ X1w)
            self.A.append(Bread[5:7] @ X1w.T)                                  # gamma_hat = A @ Dw
            self.M1.append(np.eye(2 * n) - X1w @ Bread @ X1w.T)
        N, Kp = 2 * n, 7
        self.c = n / (n - 1) * (N - 1) / (N - Kp)
        self.df1 = 2 * n - 7

    def whiten(self, D):
        return np.matmul(self.Wh, D)

    def stats(self, D, which=("W", "F", "gamma")):
        """D (..., 2n, E) differences -> dict of arrays (..., K, E): robust Wald W, homoscedastic F, gamma (..., K, 2, E)"""
        Dw = self.whiten(D); n = self.n; out = {}
        rss0 = (np.matmul(self.M0, Dw) ** 2).sum(-2)
        Ws, Fs, Gs = [], [], []
        for k in range(self.K):
            g = np.matmul(self.A[k], Dw)                                       # (..., 2, E)
            e = np.matmul(self.M1[k], Dw)                                      # (..., 2n, E)
            if "W" in which:
                Ak = self.A[k]                                                 # cluster score of animal i: A[:, i] e_i + A[:, n+i] e_{n+i}
                u0 = Ak[0, :n, None] * e[..., :n, :] + Ak[0, n:, None] * e[..., n:, :]
                u1 = Ak[1, :n, None] * e[..., :n, :] + Ak[1, n:, None] * e[..., n:, :]
                V00 = (u0 ** 2).sum(-2); V11 = (u1 ** 2).sum(-2); V01 = (u0 * u1).sum(-2)
                det = V00 * V11 - V01 ** 2
                g0, g1 = g[..., 0, :], g[..., 1, :]
                Ws.append((g0 ** 2 * V11 - 2 * g0 * g1 * V01 + g1 ** 2 * V00) / np.clip(det, 1e-300, None) / self.c)
            if "F" in which:
                rss1 = (e ** 2).sum(-2); Fs.append(((rss0 - rss1) / 2) / (rss1 / self.df1))
            Gs.append(g)
        if Ws: out["W"] = np.stack(Ws, -2)
        if Fs: out["F"] = np.stack(Fs, -2)
        out["gamma"] = np.stack(Gs, -3)
        return out

    def restricted(self, D):
        b = self.P0w @ self.whiten(D); fit = self.X0 @ b
        return fit, D - fit

    def boot(self, D, v, which=("W", "F"), chunk=250):
        """bootstrap statistics under the restricted model; v (B, n) Rademacher -> dict (B, K, E)"""
        fit, res = self.restricted(D); out = {k: [] for k in which}
        for a in range(0, len(v), chunk):
            vv = np.concatenate([v[a:a + chunk], v[a:a + chunk]], 1)
            st = self.stats(fit[None] + res[None] * vv[:, :, None], which)
            for k in which: out[k].append(st[k])
        return {k: np.concatenate(x, 0) for k, x in out.items()}


def stack(E, an_FD, edge_cols=None):
    """E: phase -> (n, m) arrays; returns stacked differences (2n, m) [L - B; S - B] and dFD_L, dFD_S"""
    D = np.vstack([E["L"] - E["B"], E["S"] - E["B"]])
    return D if edge_cols is None else D[:, edge_cols], an_FD["L"] - an_FD["B"], an_FD["S"] - an_FD["B"]
