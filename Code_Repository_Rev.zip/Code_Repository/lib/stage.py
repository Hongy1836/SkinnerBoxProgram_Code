"""rtlib.stage -- within-animal phase-change statistics of the core stage family H01-H06 and the 210-test edge map
(EXEC section 3): per-animal difference D = intercept + centred batch + dFD (dFD not centred: the intercept is the
batch-standardised change at dFD = 0), HC2-robust t of the intercept; null by a wild bootstrap of the restricted model
(no intercept) with HC2-scaled residuals and one Rademacher multiplier per animal shared by every contrast / column;
studentized Romano-Wolf stepdown (two-sided, max |t|)."""
import numpy as np


def design(bc, dfd):
    return np.column_stack([np.ones(len(dfd)), bc - bc.mean(), dfd])


def hc2_t(D, X):
    """D (n, m) or (B, n, m); X (n, k) -> t (HC2), estimate and SE of the intercept per column"""
    XtXi = np.linalg.inv(X.T @ X); P = XtXi @ X.T
    h = np.einsum("ij,jk,ik->i", X, XtXi, X)
    beta = P @ D if D.ndim == 2 else np.einsum("kn,bnm->bkm", P, D)
    fit = X @ beta if D.ndim == 2 else np.einsum("nk,bkm->bnm", X, beta)
    res = D - fit
    w = P[0] ** 2 / np.clip(1 - h, 1e-8, None)
    se = np.sqrt((w[:, None] * res ** 2).sum(-2)) if D.ndim == 2 else np.sqrt(np.einsum("n,bnm->bm", w, res ** 2))
    b0 = beta[0] if D.ndim == 2 else beta[:, 0]
    return b0 / se, b0, se


def classic_t(D, X):
    """classical OLS t of the intercept (r3 longit.intercept_t)"""
    XtXi = np.linalg.inv(X.T @ X); Pm = XtXi @ X.T
    beta = Pm @ D if D.ndim == 2 else np.einsum("kn,bnm->bkm", Pm, D)
    fit = X @ beta if D.ndim == 2 else np.einsum("nk,bkm->bnm", X, beta)
    res = D - fit; dof = X.shape[0] - X.shape[1]
    s2 = (res ** 2).sum(-2) / dof
    b0 = beta[0] if D.ndim == 2 else beta[:, 0]
    se = np.sqrt(s2 * XtXi[0, 0])
    return b0 / se, b0, se


def restricted(D, X):
    """restricted (no intercept) fit and HC2-scaled residuals"""
    Xr = X[:, 1:]; Pr = np.linalg.pinv(Xr); F = Xr @ (Pr @ D); R = D - F
    h = np.einsum("ij,ji->i", Xr, Pr)
    return F, R / np.sqrt(np.clip(1 - h, 1e-8, None))[:, None]


def multipliers(n, nb, seed):
    return np.random.default_rng(seed).choice([-1.0, 1.0], size=(nb, n))


def boot_t(D, X, v, stat=hc2_t, chunk=1000):
    """bootstrap statistics (B, m) of the intercept under the restricted null for multipliers v (B, n)"""
    F, R = restricted(D, X); out = []
    for a in range(0, len(v), chunk):
        Ds = F[None] + R[None] * v[a:a + chunk, :, None]
        out.append(stat(Ds, X)[0])
    return np.concatenate(out, 0)


def single_p(t0, tb):
    """two-sided bootstrap P per column"""
    return (1 + (np.abs(tb) >= np.abs(t0)[None] - 1e-12).sum(0)) / (len(tb) + 1)


def romano_wolf(t0, tb):
    """studentized Romano-Wolf stepdown adjusted P (two-sided); t0 (m,), tb (B, m)"""
    a = np.abs(t0); Ab = np.abs(tb); order = np.argsort(-a); padj = np.empty(len(a)); prev = 0.0
    for k, j in enumerate(order):
        mx = Ab[:, order[k:]].max(1)
        p = (1 + np.sum(mx >= a[j] - 1e-12)) / (len(tb) + 1)
        prev = max(prev, p); padj[j] = prev
    return padj


def maxt_p(t0, tb):
    """single-step max-|t| FWER P per column"""
    mx = np.abs(tb).max(1)
    return np.array([(1 + np.sum(mx >= abs(x) - 1e-12)) / (len(tb) + 1) for x in t0])


def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); out = np.empty_like(p); run = 0.0
    for i, k in enumerate(o):
        run = max(run, min(1.0, (len(p) - i) * p[k])); out[k] = run
    return out


def bh(p):
    p = np.asarray(p, float); n = len(p); o = np.argsort(p); q = np.empty(n); run = 1.0
    for i in range(n - 1, -1, -1):
        run = min(run, p[o[i]] * n / (i + 1)); q[o[i]] = run
    return q


def by(p):
    return np.minimum(1.0, bh(p) * np.sum(1.0 / np.arange(1, len(p) + 1)))
