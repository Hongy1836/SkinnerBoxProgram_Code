from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *
def partial_matrix(A,x,C):
    X=np.c_[np.ones(len(x)),C];M=np.eye(len(x))-X@np.linalg.pinv(X)
    a=M@A;b=M@x
    return (a.T@b)/np.maximum(np.sqrt((a*a).sum(0)*(b*b).sum()),1e-14)

def assoc_p(A,x,C,perms):
    X=np.c_[np.ones(len(x)),C];M=np.eye(len(x))-X@np.linalg.pinv(X);a=M@A;b=M@x
    obs=partial_matrix(A,x,C);ex=np.zeros(A.shape[1])
    for start in range(0,len(perms),200):
        pp=np.einsum('ij,bjk->bik',M,a[perms[start:start+200]],optimize=True)
        r=np.einsum('n,bnj->bj',b,pp)/np.maximum(np.sqrt((pp*pp).sum(1)*(b*b).sum()),1e-14)
        ex+=(np.abs(r)>=np.abs(obs)[None]-1e-12).sum(0)
    return obs,(ex+1)/(len(perms)+1)

def associations():
    df=pd.read_csv(OUT/'animal_behavior.csv');rng=np.random.default_rng(SEED+3)
    perms=np.array([rng.permutation(N) for _ in range(9999)])
    questions=[('L_earned','L','E01',None),('L_consumed','L','E03',None),('L_consumed_given_earned','L','E03','E01'),
      ('train_gain_earned','dL','train_gain_earned','early_earned'),('train_gain_consumed','dL','train_gain_consumed','early_consumed'),
      ('punish_change_earned','dS','punish_change_earned','late_earned'),('punish_change_consumed','dS','punish_change_consumed','late_consumed'),
      ('punish_suppression','dS','E11','late_earned')]
    cols=list(LITID.values());names=EN+['mean_'+k for k in LITID];rows=[]
    for key,ly,target,start in questions:
        D=np.c_[XFC[ly],XFC[ly]@W[:,cols]];C=np.c_[BD,MOTION[ly]];x=df[target].to_numpy()
        if key=='L_consumed_given_earned':C=np.c_[C,df[start]]
        r,p=assoc_p(D,x,C,perms)
        rankr=partial_matrix(np.apply_along_axis(stats.rankdata,0,D),stats.rankdata(x),C)
        lr=np.array([partial_matrix(D[np.arange(N)!=i],x[np.arange(N)!=i],C[np.arange(N)!=i]) for i in range(N)])
        for j,name in enumerate(names):
            # Baseline adjustment uses the matching FC start per feature.
            rbase=np.nan;pbase=np.nan
            if ly in ['dL','dS']:
                bp='B' if ly=='dL' else 'L';A=np.c_[E[bp],E[bp]@W[:,cols]]
                Cb=np.c_[C,df[start].to_numpy(),A[:,j]];rb=partial_matrix(D[:,[j]],x,Cb)[0]
                dof=N-np.linalg.matrix_rank(np.c_[np.ones(N),Cb])-1
                pb=2*stats.t.sf(abs(rb)*np.sqrt(dof/max(1-rb*rb,1e-12)),dof)
                rbase=rb;pbase=pb
            width=1.96/np.sqrt(N-C.shape[1]-3)
            rows.append(dict(question=key,layer=ly,behavior=target,feature=name,r=r[j],P=p[j],
               CI_low=np.tanh(np.arctanh(r[j])-width),CI_high=np.tanh(np.arctanh(r[j])+width),spearman_partial=rankr[j],
               loo_min_r=lr[:,j].min(),loo_max_r=lr[:,j].max(),loo_same_direction=float(np.mean(np.sign(lr[:,j])==np.sign(r[j]))),
               baseline_adjusted_r=rbase,baseline_adjusted_P_approx=pbase))
        log('Brain-behavior '+key+' complete.')
    pd.DataFrame(rows).to_csv(OUT/'brain_behavior_associations.csv',index=False)
if __name__=='__main__':
 BH.reset_index().to_csv(OUT/'animal_behavior.csv',index=False)
 associations()
