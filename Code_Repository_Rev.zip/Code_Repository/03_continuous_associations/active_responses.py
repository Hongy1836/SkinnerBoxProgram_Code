from run import *
daily=pd.read_csv(SD1/'daily_behavior_31mice_19sessions.csv')
y=daily[(daily.phase=='training')&(daily.study_day>=8)].groupby('animal').total_active_presses.mean().loc[AN].to_numpy()
ix=[i for i,p in enumerate(PAIRS) if set(p)<=set(['DLS','M1','AI','NAc','VTA','LHA'])]
perms=np.array([np.random.default_rng(20261019+i).permutation(N) for i in range(9999)])
r,p=assoc_p(E['L'][:,ix],y,np.c_[BD,FD['L']],perms);width=1.96/np.sqrt(26)
pd.DataFrame(dict(feature=[EN[i] for i in ix],r=r,P=p,CI_low=np.tanh(np.arctanh(r)-width),CI_high=np.tanh(np.arctanh(r)+width),n=N,n_permutations=9999)).to_csv(OUT/'All15_total_active_presses.csv',index=False)
