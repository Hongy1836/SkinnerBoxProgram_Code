from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *
def refine_group(ly,ids):
    D=XFC[ly]@W[:,ids];X=group_design(ly);t=stage.hc2_t(D,X)[0]
    V=stage.multipliers(N,9999,SEED+4)
    p=stage.single_p(t,stage.boot_t(D,X,V,chunk=100))
    rr=[]
    for j,idx in enumerate(ids):
        lr=[]
        for i in range(N):
            keep=np.arange(N)!=i;lr.append(stage.hc2_t(D[keep][:,[j]],group_design(ly,np.flatnonzero(keep)))[1][0])
        row=dict(layer=ly,subset_id=int(idx),P_wild=p[j],loo_min_effect=min(lr),loo_max_effect=max(lr),loo_same_direction=float(np.mean(np.sign(lr)==np.sign(stage.hc2_t(D[:,[j]],X)[1][0]))))
        for batch in ['B1','B2']:
            mask=BT==batch;xx=np.c_[Y[mask],np.ones(mask.sum()),MOTION[ly][mask]]
            z=raw_ols(D[mask][:,[j]],xx);row[batch+'_effect']=z['effect'][0];row[batch+'_P_approx']=z['P_approx'][0]
        rr.append(row)
    return rr

def exhaustive():
    rr=[];selected={};A={p:E[p]@W for p in 'BLS'}
    for ly in LAYERS:
        D=XFC[ly]@W;res=raw_ols(D,group_design(ly));tab=SUBMETA.copy();tab['layer']=ly
        for k,v in res.items():tab[k]=v
        tab['low_mean']=D[Y==0].mean(0);tab['high_mean']=D[Y==1].mean(0);rr.append(tab)
        selected[ly]=sorted(set(np.argsort(res['P_approx'])[:20])|set(LITID.values()))
    allres=pd.concat(rr,ignore_index=True);allres.to_csv(OUT/'all8178_network_group_effects.csv',index=False)
    D,dl,ds=interact.stack(A,FD);mdl=interact.Interaction(BD,dl,ds,Y[:,None]);s=mdl.stats(D)
    tab=SUBMETA.copy();tab['W_CR1']=s['W'][0];tab['P_approx']=stats.f.sf(s['W'][0]/2,2,N-1)
    tab['effect_LB']=s['gamma'][0,0]/Y.std(ddof=1);tab['effect_SB']=s['gamma'][0,1]/Y.std(ddof=1)
    tab.to_csv(OUT/'all8178_network_interactions.csv',index=False)
    ids=sorted(set(np.argsort(tab.P_approx)[:20])|set(LITID.values()))
    V=stage.multipliers(N,9999,SEED+4);obs=mdl.stats(D[:,ids])['W'][0]
    null=mdl.boot(D[:,ids],V,which=('W',),chunk=100)['W'][:,0]
    pt=(1+(null>=obs[None]-1e-12).sum(0))/10000
    part=tab.iloc[ids].copy();part['P_wild']=pt
    lfx=[]
    for i in range(N):
        ix=np.flatnonzero(np.arange(N)!=i)
        mo=interact.Interaction(BD[ix],dl[ix],ds[ix],Y[ix,None]);di=np.r_[ix,N+ix]
        si=mo.stats(D[di][:,ids]);lfx.append(si['gamma'][0]/Y[ix].std(ddof=1))
    lfx=np.array(lfx)
    for k,layer in enumerate(['LB','SB']):
        part['loo_min_'+layer]=lfx[:,k].min(0);part['loo_max_'+layer]=lfx[:,k].max(0)
    for batch in ['B1','B2']:
        # Within-batch group differences of both changes; avoid singular constant batch column.
        ix=np.flatnonzero(BT==batch)
        for layer in ['dL','dS']:
            res=raw_ols((XFC[layer]@W)[ix][:,ids],np.c_[Y[ix],np.ones(len(ix)),MOTION[layer][ix]])
            part[batch+'_'+layer+'_effect']=res['effect']
    part.to_csv(OUT/'selected_network_interactions_wild.csv',index=False)
    refined=[]
    for ly in LAYERS:
        refined+=refine_group(ly,selected[ly]);log('Exhaustive '+ly+' scanned all 8178; selected wild-bootstrap checks complete.')
    pd.DataFrame(refined).merge(SUBMETA,on='subset_id').to_csv(OUT/'selected_network_group_wild.csv',index=False)
    allres[allres.subset_id.isin(LITID.values())].assign(network=lambda t:t.subset_id.map({v:k for k,v in LITID.items()})).to_csv(OUT/'literature_network_group_effects.csv',index=False)
    bysize=allres.sort_values('P_approx').groupby(['layer','n_roi']).head(1)
    bysize.to_csv(OUT/'best_by_size_group.csv',index=False)
    tab.sort_values('P_approx').groupby('n_roi').head(1).to_csv(OUT/'best_by_size_interaction.csv',index=False)
    savej(OUT/'statistical_search_coverage.json',dict(n_subsets=NS,group_tests=len(allres),interaction_tests=len(tab),raw_P=True,corrected=False,
      top_checks_per_question=20,n_wild=9999,selection_note='Selected-network confidence intervals and P values are unadjusted exploratory; not valid confirmation after search.'))
    log('All 40890 group contrasts and 8178 interactions complete; no subset omitted.')
if __name__=='__main__':exhaustive()
