from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from common import *

def run():
 core=[(a,b) for a in ['ACC','PrL','M1','AI'] for b in ['NAc','DMS','DLS']]
 ix=lambda p:next(j for j,e in enumerate(PAIRS) if set(p)==set(e))
 X=group_design('B');D=E['B'][:,[ix(p) for p in core]];V=stage.multipliers(N,9999,20261018)
 def output(D,names,name,X):
  r=raw_ols(D,X);p=stage.single_p(r['t'],stage.boot_t(D,X,V));t=pd.DataFrame(r);t['P_wild']=p;t['connection']=names;t.to_csv(OUT/(name+'.csv'),index=False);return t
 t=output(D,['–'.join(p) for p in core],'baseline_candidates_12',X)
 ref=pd.read_csv(ROOT/'Supplementary_Data_2/focused_comparisons/baseline_candidates_12.csv');np.testing.assert_allclose(t.P_wild,ref.P_wild)
 output(np.c_[D[:,1]-D[:,0],D[:,1]-D[:,2]],['ACC–DMS minus ACC–NAc','ACC–DMS minus ACC–DLS'],'direct_specificity_contrasts',X)
 tri=[ix(p) for p in [('DLS','M1'),('DLS','AI'),('M1','AI')]]
 output(XFC['dL'][:,tri],[EN[j] for j in tri],'triad_edge_changes',group_design('dL'))
 A={p:E[p][:,tri].mean(1,keepdims=True) for p in 'BLS'};D,dl,ds=interact.stack(A,FD);model=interact.Interaction(BD,dl,ds,Y[:,None]);obs=model.stats(D)['W'][0]
 null=model.boot(D,V,which=('W',),chunk=100)['W'][:,0];p=(1+(null>=obs[None]-1e-12).sum(0))/10000
 pd.DataFrame({'W':obs,'P_wild':p}).to_csv(OUT/'triad_interaction.csv',index=False)
 output((A['L']-A['B']),['DLS-M1-AI'],'triad_change',group_design('dL'))
 V=stage.multipliers(N,9999,20261017)
 output((A['L']-A['B']),['DLS-M1-AI'],'triad_change_start_adjusted',np.c_[group_design('dL'),A['B']])
 print('Baseline comparisons and triad trajectories calculated.')
if __name__=='__main__':run()
