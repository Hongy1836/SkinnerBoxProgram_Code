# Mouse food earning and resting-state connectivity

This repository runs the behavioral, connectivity and fixed-classifier analyses for 31 mice and 13 sampled brain regions. Place it beside Supplementary_Data_1, Supplementary_Data_2 and Supplementary_Data_3, preserving the supplied directory names.

## Environment and execution

Use Python 3.12.12. The exact tested package versions are pinned in requirements.txt and environment.json.

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py --catalogue --figures
```

Outputs are written below `outputs/`; input measurements are read from Supplementary_Data_1. No absolute workstation paths are required. Arial is used where installed; Matplotlib may substitute an available font otherwise. Figure exports include vector PDF/SVG and 600-dpi PNG.

## Analysis modules

1. `01_behavior_clustering`: fixed four-feature labels and LOO reconstruction, plus explicitly parameterized cluster diagnostics and 500-bootstrap recalculation. Original FigS1 ARI settings and FigS2 radar normalization are unavailable; recalculations are separate outputs, not replacements for saved summaries.
2. `02_stage_changes_NBS`: HC2 stage contrasts and classical-t component NBS, each with 9,999 null-imposed wild draws. Seeds 3822434024 (edges) and 47724983 (NBS).
3. `03_continuous_associations`: residual-permutation associations and starting-value/rank/LOO sensitivities; seed 20261017 for continuous associations. Total-active-response permutations use seed 20261019+i for draw i.
4. `04_group_trajectories_and_baseline`: GLS trajectories, HC2 group comparisons and all 8,178 ROI subsets. Seed 20261018; baseline-adjusted triad sensitivity uses its recorded seed 20261017.
5. `05_nearest_centroid_classifiers`: seven fixed scalar inputs, training-only FD regression, signed centroid normalization and inner stratified three-fold threshold choice from [0, −0.25, 0.25]. Outer LOO seed is 20261114+i; batch 2→1 seed is 20261914. All 287 stored scores and labels are asserted against the supplied reference records.
6. `06_figure_generation`: production figure builders with packaged anatomical and numerical assets. These regenerate Fig2–Fig5 and FigS5–FigS8 from supplied plotting values. Statistical recomputation and figure regeneration are separate steps; the figure engines do not silently substitute recomputed values.

## Reproduction coverage

Stage and NBS values, continuous associations, all-subset group/interaction statistics, six/12 baseline comparisons, triad interaction and baseline sensitivity, and all seven fixed classifier predictions were tested against supplied outputs. The broad alternative-classifier catalogue is supplied as data; its entire algorithm search is not rerun by this entry point.

A complete reconstruction of all manuscript artwork is not yet available: original Fig1 and FigS1–FigS4 production builders, FigS1 ARI settings and FigS2 radar scaling were not found in the available corpus. Figure inputs are supplied, but this repository does not claim to recreate those original panels. New bootstrap diagnostics have explicit settings and are labeled as recalculations. Raw fMRI preprocessing is outside this processed-FC workflow.

See ../reproduction_validation.json for executed numerical comparisons and ../Supplementary_Data_3/figure_panel_index.csv for source coverage. Repository publication and licensing should be completed by the authors before assigning a DOI.
