"""Print-scale plotting helpers. Saved estimates only; no fitting routines."""
from pathlib import Path
import os, json
HERE=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(HERE/'review/mpl_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox
from matplotlib.text import Text
LOW='#2B5C8F'; HIGH='#C84B31'; DARK='#333333'; GRAY='#888888'
plt.rcParams.update({'font.family':'Arial','font.size':6.5,'axes.labelsize':7.5,
 'axes.titlesize':8,'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,
 'axes.linewidth':.75,'xtick.major.width':.75,'ytick.major.width':.75,
 'xtick.major.size':2.5,'ytick.major.size':2.5,'xtick.direction':'out','ytick.direction':'out',
 'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,
 'axes.spines.right':False,'text.color':DARK,'axes.labelcolor':DARK,'xtick.color':DARK,
 'ytick.color':DARK,'legend.frameon':False,'savefig.facecolor':'white'})
META=[]; TEXT_AUDIT=[]
def source(name,t):
 t.to_csv(HERE/'source_data'/f'{name}.csv',index=False,float_format='%.17g')
 return t
def read(name): return pd.read_csv(HERE/'inputs'/f'{name}.csv')
def canvas(): return plt.figure(figsize=(180/25.4,160/25.4))
def axes(fig,x,y,w,h): return fig.add_axes([x/180,y/160,w/180,h/160])
def textmm(fig,x,y,s,**kw):
 return fig.text(x/180,y/160,s,**kw)
def header(fig,letter,title,x,y):
 textmm(fig,x,y,letter,fontsize=9.5,fontweight='bold',va='top')
 textmm(fig,x+6,y-.2,title,fontsize=8,va='top')
def key(fig):
 handles=[Line2D([],[],color=LOW,ls='--',marker='o',mfc='white',mec=LOW,ms=3.6,lw=1,label='Low earners (n = 13)'),
  Line2D([],[],color=HIGH,ls='-',marker='o',mfc=HIGH,mec=HIGH,alpha=.88,ms=3.6,lw=1,label='High earners (n = 18)'),
  Line2D([],[],ls='',marker='s',mfc='none',mec=DARK,ms=3.6,label='Batch 1 (n = 10)'),
  Line2D([],[],ls='',marker='o',mfc='none',mec=DARK,ms=3.6,label='Batch 2 (n = 21)')]
 fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.995),ncol=4,
            handlelength=1.4,handletextpad=.45,columnspacing=1.5)
def zero(ax,orientation='h',value=0):
 (ax.axhline if orientation=='h' else ax.axvline)(value,color=GRAY,ls=':',lw=.8,zorder=0)
def animal_points(ax,x,y,groups,batches,size=15):
 for g,col in [(0,LOW),(1,HIGH)]:
  for b,m in [('B1','s'),('B2','o')]:
   ix=(np.asarray(groups)==g)&(np.asarray(batches)==b)
   ax.scatter(np.asarray(x)[ix],np.asarray(y)[ix],s=size,marker=m,
       fc='white' if g==0 else col,ec=col,alpha=1 if g==0 else .88,lw=.75,zorder=4)
def dots(ax,t,value,compact=False):
 for g,col in [(0,LOW),(1,HIGH)]:
  sub=t[t.group==g];v=sub[value].to_numpy(); x=g+np.linspace(-.18,.18,len(v))
  animal_points(ax,x,v,sub.group,sub.batch)
  mu=v.mean();se=v.std(ddof=1)/np.sqrt(len(v))
  ax.plot([g-.24,g+.24],[mu,mu],color=col,lw=1.8,zorder=5)
  ax.errorbar(g,mu,yerr=se,fmt='none',ecolor=col,lw=1.1,capsize=2.4,zorder=5)
 ax.set_xlim(-.48,1.48)
 ax.set_xticks([0,1],['Low','High'] if compact else ['Low earners\n(n = 13)','High earners\n(n = 18)'])
 ax.margins(y=.18)
def save(fig,name,cells):
 apply_p_style(fig);record_axes(fig,name,HERE/"review")
 """Full page at exactly 180 x 160 mm; cropped panels retain physical scale."""
 fig.canvas.draw()
 for a in fig.axes:
  if not a.axison:a.set_xticks([]);a.set_yticks([])
  for aa,lim in [(a.xaxis,a.get_xlim()),(a.yaxis,a.get_ylim())]:
   for tick in aa.get_major_ticks():
    if not min(lim)<=tick.get_loc()<=max(lim):tick.label1.set_visible(False)
    tick.label2.set_visible(False)
 fig.canvas.draw();r=fig.canvas.get_renderer()
 entries=[]
 for t in fig.findobj(match=lambda a:isinstance(a,Text)):
  if not t.get_visible() or not t.get_text().strip():continue
  b=t.get_window_extent(r);outside=b.x0<-.5 or b.y0<-.5 or b.x1>fig.bbox.x1+.5 or b.y1>fig.bbox.y1+.5
  entries.append(dict(text=t.get_text(),fontsize=t.get_fontsize(),outside=bool(outside),bbox_px=list(b.extents)))
 TEXT_AUDIT.append(dict(figure=name,text=entries))
 for ext in ['pdf','svg','png']:fig.savefig(HERE/'figures'/f'{name}.{ext}',dpi=600)
 fig.savefig(HERE/'review'/f'{name}_preview.png',dpi=200)
 for letter,(x,y,w,h) in cells.items():
  shown=[]
  for a in fig.axes:
   pos=a.get_position();cx=(pos.x0+pos.x1)*90;cy=(pos.y0+pos.y1)*80
   vis=x<=cx<=x+w and y<=cy<=y+h;a.set_visible(vis)
   if vis:shown.append(a)
  for t in fig.texts:
   xx,yy=t.get_position();t.set_visible(x<=xx*180<=x+w and y<=yy*160<=y+h)
  for l in fig.legends:l.set_visible(False)
  fig.canvas.draw();r=fig.canvas.get_renderer()
  bb=Bbox.from_bounds(x/25.4,y/25.4,w/25.4,h/25.4)
  pieces=[bb.transformed(fig.dpi_scale_trans)]
  pieces += [a.get_tightbbox(r) for a in shown if a.get_tightbbox(r) is not None]
  pieces += [t.get_window_extent(r) for t in fig.texts if t.get_visible()]
  bb=Bbox.union(pieces).transformed(fig.dpi_scale_trans.inverted())
  for ext in ['pdf','svg','png']:
   fig.savefig(HERE/'figures/panels'/f'{name}{letter}.{ext}',dpi=600,bbox_inches=bb,pad_inches=0)
  for a in fig.axes:a.set_visible(True)
  for t in fig.texts:t.set_visible(True)
  for l in fig.legends:l.set_visible(True)
 META.append(dict(figure=name,width_mm=180,height_mm=160,panels=list(cells),png_dpi=600))
 plt.close(fig)

from typography import apply_p_style,record_axes
