"""Reorganized Fig. 4/5 and Supplementary Fig. 5 from frozen inputs only.
No classifiers are instantiated, trained or tuned. No inferential estimates are recomputed.
Only display summaries (raw means/SEM) and checks of saved predictions are calculated.
"""
from style import *
from anatomy import brain,POS,LAB,COL,CON
from matplotlib.patches import Rectangle
import hashlib,sys

CORE=['ACC–NAc','ACC–DMS','ACC–DLS','PrL–NAc','PrL–DMS','PrL–DLS']
TRI=['DLS-M1','M1-AI','DLS-AI']
z=np.load(HERE/'inputs/frozen_data13.npz',allow_pickle=True)
base=read('baseline_prefrontal_striatal_6').set_index('connection').loc[CORE].reset_index()
perf=read('six_fixed_classifier_performance')
pred=read('six_fixed_classifier_records')
oldperf=read('prior_Prediction_performance')
baseline_margin=read('prior_Fig5e');triad_margin=read('prior_Fig5f')
np.testing.assert_array_equal(baseline_margin.animal,triad_margin.animal)
np.testing.assert_array_equal(baseline_margin.label,[0]*7+[1]*3)
DISPLAY={a:i+1 for i,a in enumerate(baseline_margin.animal)}
checks=[]
def check(name,ok):
 assert bool(ok),name
 checks.append(dict(check=name,passed=True))
def edge_index(edge):
 a,b=edge.replace('–','-').split('-')
 return next(i for i,e in enumerate(z['edge_names']) if set(e.split('-'))=={a,b})
def baseline_data():
 rows=[]
 for e in ['ACC–DMS','ACC–DLS']:
  vals=z['B'][:,edge_index(e)]
  for a,b,g,v in zip(z['animals'],z['batch'],z['labels'],vals):
   rows.append(dict(connection=e,animal=a,batch=b,group=g,FC=v))
 return pd.DataFrame(rows)
def verify():
 for m in json.loads((HERE/'inputs/manifest.json').read_text()):
  check('Input hash: '+m['file'],hashlib.sha256((HERE/'inputs'/m['file']).read_bytes()).hexdigest()==m['sha256'])
 check('Prior audit verified frozen arrays',json.loads((HERE/'inputs/verification_prior.json').read_text())['frozen_arrays_unchanged'])
 for records,metricrows,keycol in [(pred,perf,'connection'),(read('prior_Prediction_records_all_82'),oldperf,'model')]:
  for (name,scheme),t in records.groupby([keycol,'scheme']):
   r=metricrows[(metricrows[keycol]==name)&(metricrows.scheme==scheme)].iloc[0]
   y=t.label.to_numpy();h=t.prediction.to_numpy();score=t.score.to_numpy()
   ba=((h[y==0]==0).mean()+(h[y==1]==1).mean())/2
   hi=score[y==1,None];lo=score[y==0][None,:];auc=np.mean((hi>lo)+.5*(hi==lo))
   check(f'{name}/{scheme} saved metrics',np.allclose([ba,auc,(h==y).sum()],[r.balanced_accuracy,r.auc,r.correct],atol=1e-12))
 for tag,t in [('ACC–DMS',baseline_margin),('Triad',triad_margin)]:
  check(tag+' saved margin equals score minus threshold',np.allclose(t.decision_margin,t.score-t.threshold,atol=1e-12))
  check(tag+' predictions reproduce saved threshold',np.array_equal((t.decision_margin>=0).astype(int),t.prediction))
 check('Same test-animal order',baseline_margin.animal.tolist()==triad_margin.animal.tolist())
 p=pred[(pred.connection=='ACC–DMS')&(pred.scheme=='B2toB1')].set_index('animal').loc[baseline_margin.animal]
 check('ACC–DMS records agree between frozen exports',np.allclose(p.score,baseline_margin.score) and np.array_equal(p.prediction,baseline_margin.prediction))
 check('ACC–DMS error at anonymous index 1',np.flatnonzero(baseline_margin.label!=baseline_margin.prediction).tolist()==[0])
 check('Triad errors at anonymous indices 3, 5, 7',np.flatnonzero(triad_margin.label!=triad_margin.prediction).tolist()==[2,4,6])
 t=read('prior_Fig4b');ix=[edge_index(e) for e in TRI]
 for phase in 'BLS':
  v=t[t.phase==phase].set_index('animal').loc[z['animals'],'mean_FC']
  check('Triad '+phase+' equals all-three-edge mean',np.allclose(v,z[phase][:,ix].mean(1),atol=1e-12))
 d=read('prior_Fig4c').set_index('animal').loc[z['animals'],'delta_FC']
 check('Training change equals saved after minus before',np.allclose(d,(z['L'][:,ix]-z['B'][:,ix]).mean(1),atol=1e-12))
 for e,t in baseline_data().groupby('connection'):
  row=base[base.connection==e].iloc[0]
  check(e+' raw means agree with saved estimates',np.allclose([t[t.group==0].FC.mean(),t[t.group==1].FC.mean()],[row.low_mean,row.high_mean]))
 source('Anonymous_test_animal_order',pd.DataFrame(dict(anonymous_index=range(1,11),animal=baseline_margin.animal,label=baseline_margin.label)))

def forest(a,t,labels=None,pc='P_wild',color=LOW,xlim=(-.32,.055),ticks=(-.3,-.2,-.1,0),pcol=True):
 for j,r in enumerate(t.itertuples()):
  yy=len(t)-1-j;pv=getattr(r,pc);on=pv<.05;c=color if on else '#666666'
  a.errorbar(r.effect,yy,xerr=[[r.effect-r.CI_low],[r.CI_high-r.effect]],fmt='o',
      mfc=c if on else 'white',mec=c,ecolor=c,ms=3.6,lw=.85,capsize=2)
  if pcol:a.text(1.045,yy,f'{pv:.4f}',transform=a.get_yaxis_transform(),va='center',fontsize=6.5)
 a.set_yticks(range(len(t)-1,-1,-1),labels if labels is not None else t.connection)
 a.tick_params(axis='y',length=0,pad=4);a.set_xlim(*xlim);a.set_xticks(ticks);a.set_ylim(-.55,len(t)-.15)
 zero(a,'v')
 if pcol:a.text(1.045,1.02,'P',transform=a.transAxes,fontsize=6.5)

def performance(fig,rows,x,y,w,h,prefix):
 """Two symmetric metric axes with exact correct counts explicitly identified."""
 out=[]
 for k,(met,title) in enumerate([('balanced_accuracy','Balanced accuracy'),('auc','ROC AUC')]):
  a=axes(fig,x+14+k*(w/2),y+9,w/2-17,h-20)
  for j,scheme in enumerate(['LOO','B2toB1']):
   r=rows[rows.scheme==scheme].iloc[0];yy=1-j;c=LOW if j==0 else HIGH
   a.scatter(r[met],yy,s=21,marker='o' if j==0 else 's',fc=c if j==0 else 'white',ec=c,lw=.9,zorder=3)
   lab=f'{r[met]*100:.1f}% ({int(r.correct)}/{int(r.n)} correct)' if k==0 else f'{r[met]:.3f}'
   a.text(1.035,yy+.23,lab,ha='right',va='bottom',fontsize=6.5)
  a.set_yticks([1,0],['LOO','2 → 1']);a.tick_params(axis='y',length=0,pad=3)
  a.set_ylim(-.45,1.6);a.set_xlim(.44,1.04);a.set_xticks([.5,.75,1],['0.50','0.75','1.00'])
  a.set_title(title,fontsize=7.5,pad=6);zero(a,'v',.5)
 textmm(fig,x+w/2,y+1,'LOO: n = 31 · Batch 2 → 1: 21 → 10 mice',ha='center',fontsize=6.5)
 source(prefix,rows)

def margin(fig,t,x,y,w,h,tag):
 a=axes(fig,x,y,w,h)
 for r in t.itertuples():
  xx=DISPLAY[r.animal];col=LOW if r.label==0 else HIGH
  a.scatter(xx,r.decision_margin,s=20,marker='s',fc='white' if r.label==0 else col,
            ec=col,alpha=1 if r.label==0 else .88,lw=.8,zorder=3)
  if r.label!=r.prediction:a.scatter(xx,r.decision_margin,s=64,marker='o',fc='none',ec='#444444',lw=.8,zorder=2)
 zero(a);a.set_xlim(.35,10.65);a.set_ylim(-4.4,3.6);a.set_yticks([-4,-2,0,2]);a.set_xticks(range(1,11))
 a.set_xlabel('Test animal (anonymous display index)',labelpad=3);a.set_ylabel('Decision margin',labelpad=3)
 a.text(.98,.96,'Predicted high',transform=a.transAxes,ha='right',va='top',fontsize=6.5)
 a.text(.98,.04,'Predicted low',transform=a.transAxes,ha='right',va='bottom',fontsize=6.5)
 lo=t[t.label==0];hi=t[t.label==1]
 a.text(.5,1.10,f'Low: {int((lo.prediction==0).sum())}/{len(lo)} · High: {int((hi.prediction==1).sum())}/{len(hi)}',
        transform=a.transAxes,ha='center',fontsize=6.5)
 source(tag,t.assign(anonymous_index=t.animal.map(DISPLAY)))

def fig4():
 f=canvas();key(f)
 header(f,'a','From Fig. 3 to a single ΔFC feature',2,150)
 a=axes(f,1,116,46,29);brain(a,['DLS','M1','AI'],TRI,curve_radii={'DLS-M1':.4,'M1-AI':.35,'DLS-AI':.5})
 textmm(f,24,112,'3-node representation\nAll 3 internal edges averaged equally',ha='center',va='top',fontsize=6.5)
 a=axes(f,49,110,40,35);a.axis('off')
 labs=['3-edge unweighted mean ΔFC\n(After − Before training)','Training-only ΔFD\nresidualization',
       '1D nearest-centroid\n+ inner-CV threshold','Held-out group label']
 for i,lab in enumerate(labs):
  yy=.91-i*.27;a.text(.5,yy,lab,ha='center',va='center',fontsize=6.5)
  if i<3:a.annotate('',xy=(.5,yy-.19),xytext=(.5,yy-.10),arrowprops=dict(arrowstyle='->',lw=.65,color=DARK))
 assoc=read('triad_food_earned_associations');source('Fig4a',assoc.assign(equal_feature_weight=1/3))
 source('Fig4a_workflow',pd.DataFrame(dict(step=range(1,5),description=labs)))
 header(f,'b','DLS–M1–AI across stages',94,150)
 a=axes(f,108,118,65,25);t=read('prior_Fig4b');piv=t.pivot(index='animal',columns='phase',values='mean_FC').loc[:,list('BLS')]
 for row in piv.to_numpy():a.plot(range(3),row,color='#CCCCCC',lw=.6,alpha=.55,zorder=1)
 summary=read('prior_Fig4b_summary')
 for g,col,m,ls in [(0,LOW,'s','--'),(1,HIGH,'o','-')]:
  s=summary[summary.group==g].set_index('phase').loc[list('BLS')]
  a.errorbar(range(3),s['mean'],yerr=s.SEM,color=col,marker=m,mfc='white' if g==0 else col,
       mec=col,ls=ls,ms=3.7,lw=1.8,capsize=2,zorder=5)
 a.set_xticks(range(3),['Before\ntraining','After\ntraining','After\npunishment']);a.set_ylabel('Mean network FC (Fisher z)',labelpad=3);a.margins(x=.13,y=.15)
 inter=read('selected_network_interactions_wild');inter=inter[inter.rois=='DLS;M1;AI'];p=float(inter.P_wild.iloc[0])
 textmm(f,108,145,'Group × stage P = '+f'{p:.4f}',fontsize=6.5)
 source('Fig4b',t);source('Fig4b_summary',summary);source('Fig4b_interaction',inter)
 header(f,'c','Training-related change',2,100)
 a=axes(f,17,65,65,23);t=read('prior_Fig4c');dots(a,t,'delta_FC');zero(a);a.set_ylabel('Training ΔFC (Fisher z)',labelpad=3)
 sens=read('prior_Fig4d');r=sens.iloc[0]
 textmm(f,18,95,f'Adjusted difference = {r.effect:.3f}\nP = {r.P:.4f}',fontsize=6.5,va='top')
 source('Fig4c',t);source('Fig4c_adjusted_estimate',sens.iloc[:1])
 header(f,'d','Starting-state sensitivity',94,100)
 a=axes(f,128,65,33,25)
 for j,r in enumerate(sens.itertuples()):
  a.errorbar(r.effect,1-j,xerr=[[r.effect-r.CI_low],[r.CI_high-r.effect]],fmt='o' if j==0 else 's',
     mfc=DARK if j==0 else 'white',mec=DARK,ecolor=DARK,capsize=2,ms=3.6,lw=.85)
  a.text(1.07,1-j,f'P = {r.P:.4f}',transform=a.get_yaxis_transform(),va='center',fontsize=6.5)
 a.set_yticks([1,0],['Batch + ΔFD\nadjusted','+ Pre-training FC']);a.tick_params(axis='y',length=0,pad=3)
 a.set_xlim(-.06,.29);a.set_xticks([0,.1,.2]);a.set_ylim(-.6,1.6);zero(a,'v')
 a.set_xlabel('High − low training ΔFC\n(Fisher z, 95% CI)',labelpad=3);source('Fig4d',sens)
 header(f,'e','Fixed ΔFC classifier performance',2,49)
 performance(f,oldperf[oldperf.model.str.startswith('DLS')],2,3,85,42,'Fig4e')
 header(f,'f','Training ΔFC · held-out batch 1',94,49)
 margin(f,triad_margin,108,13,65,27,'Fig4f')
 save(f,'Fig4',{'a':(0,105,91,47),'b':(92,105,88,47),'c':(0,53,91,49),'d':(92,53,88,49),'e':(0,0,91,51),'f':(92,0,88,51)})

def upset(fig):
 order=CORE;xx=np.arange(6);x0=113;w=62
 a=axes(fig,x0,31,w,18)
 a.axvspan(.5,1.5,color='#F4EBE8',zorder=-3,lw=0)
 for j,e in enumerate(order):
  rows=perf[perf.connection==e].set_index('scheme')
  values=[float(rows.loc[s,'balanced_accuracy']) for s in ['LOO','B2toB1']]
  label_y=[v+.025 for v in values]
  if max(values)>.85:label_y=[v-.11 for v in values]
  elif abs(values[0]-values[1])<.09:label_y[int(np.argmin(values))]=min(values)-.10
  for h,scheme in enumerate(['LOO','B2toB1']):
   xpos=j+(-.17 if h==0 else .17);v=float(rows.loc[scheme,'balanced_accuracy']);col='#3B75AF' if h==0 else HIGH
   a.plot([xpos,xpos],[.40,v],color=col,lw=1.8,zorder=2)
   a.scatter(xpos,v,s=11,marker='o' if h==0 else 's',ec=col,fc=col if h==0 else 'white',lw=.8,zorder=3)
   a.text(xpos,label_y[h],f'{100*v:.1f}',ha='center',va='bottom',fontsize=6.5,
          bbox=dict(fc='#F4EBE8' if j==1 else 'white',ec='none',pad=.04))
 a.set_xlim(-.55,5.55);a.set_ylim(.4,1.0);a.set_yticks([.5,.75,1],['0.50','0.75','1.00']);a.set_xticks([]);a.tick_params(axis='x',length=0)
 a.set_ylabel('Balanced\naccuracy',labelpad=2);zero(a,'h',.5)
 a.spines['bottom'].set_visible(False)
 keyhandles=[Line2D([],[],color='#3B75AF',marker='o',lw=1.2,ms=3,label='LOO'),Line2D([],[],color=HIGH,marker='s',mfc='white',lw=1.2,ms=3,label='2 → 1')]
 a.legend(handles=keyhandles,loc='upper left',bbox_to_anchor=(0,1.17),ncol=2,columnspacing=1.2,handletextpad=.4,handlelength=1.1,borderaxespad=0)
 b=axes(fig,x0,9,w,17)
 b.axvspan(.5,1.5,color='#F4EBE8',zorder=-3,lw=0)
 nodes=['ACC','PrL','NAc','DMS','DLS']
 for j,e in enumerate(order):
  b.scatter(np.full(5,j),range(4,-1,-1),s=12,fc='#E2E2E2',ec='none',zorder=1)
  active=[4-nodes.index(n) for n in e.split('–')]
  b.plot([j,j],active,color='black',lw=1.8,zorder=2)
  b.scatter([j,j],active,s=16,fc='#C85A53',ec='#C85A53',lw=.4,zorder=3)
 b.set_xlim(-.55,5.55);b.set_ylim(-.6,4.6);b.set_yticks(range(4,-1,-1),nodes);b.set_xticks([]);b.tick_params(axis='y',length=0,pad=3)
 for s in b.spines.values():s.set_visible(False)
 # A dedicated numeric row keeps AUC distinct from the balanced-accuracy axis.
 textmm(fig,109,28.4,'AUC',ha='right',va='center',fontsize=6.5)
 for j,e in enumerate(order):
  auc=perf[(perf.connection==e)&(perf.scheme=='B2toB1')].auc.iloc[0]
  textmm(fig,x0+w*(j+.55)/6.1,28.4,f'{auc:.3f}',ha='center',va='center',fontsize=6.5)
 textmm(fig,144,4.0,'AUC row: Batch 2 → 1',ha='center',fontsize=6.5)
 source('Fig5f',perf.assign(display_column=perf.connection.map({e:i+1 for i,e in enumerate(order)})))
 source('Fig5f_node_membership',pd.DataFrame([dict(column=j+1,connection=e,ROI=n,member=n in e.split('–')) for j,e in enumerate(order) for n in nodes]))

def fig5():
 f=canvas();key(f)
 header(f,'a','Prefrontal–striatal comparison framework',2,150)
 a=axes(f,3,114,83,29);edges=[e.replace('–','-') for e in CORE]
 brain(a,['ACC','PrL','NAc','DMS','DLS'],edges,signed={r.connection.replace('–','-'):(r.effect,r.P_wild) for r in base.itertuples()},
       curve_radii=dict(zip(edges,[.25,-.8,.35,-.65,.8,-.45])))
 textmm(f,45,109.5,'2 prefrontal × 3 striatal ROIs\nAll 6 baseline connections',ha='center',va='top',fontsize=6.5)
 source('Fig5a',base)
 header(f,'b','All six baseline group differences',94,150)
 a=axes(f,119,115,45,28);forest(a,base);a.set_xlabel('High − low pre-training FC\n(Fisher z, 95% CI)',labelpad=3)
 source('Fig5b',base)
 header(f,'c','Two baseline connections with group differences',2,100)
 t=baseline_data();lim=(t.FC.min()-.08,t.FC.max()+.10)
 for j,e in enumerate(['ACC–DMS','ACC–DLS']):
  a=axes(f,17+j*40,64,27,23);dots(a,t[t.connection==e],'FC',True);a.set_ylim(*lim)
  a.set_title(e,pad=17,fontsize=7.5)
  r=base[base.connection==e].iloc[0]
  a.text(.5,1.02,f'Diff = {r.effect:.3f}\nP = {r.P_wild:.4f}',transform=a.transAxes,ha='center',va='bottom',fontsize=6.5)
  if j==0:a.set_ylabel('Pre-training FC (Fisher z)',labelpad=3)
  else:a.tick_params(axis='y',labelleft=False)
 source('Fig5c',t);source('Fig5c_adjusted_estimates',base[base.connection.isin(['ACC–DMS','ACC–DLS'])])
 header(f,'d','ACC–DMS classifier performance',94,100)
 performance(f,perf[perf.connection=='ACC–DMS'],94,60,84,36,'Fig5d')
 header(f,'e','ACC–DMS · held-out batch 1',2,55)
 margin(f,baseline_margin,17,15,66,29,'Fig5e')
 header(f,'f','Six fixed baseline classifiers',94,55)
 upset(f)
 save(f,'Fig5',{'a':(0,104,91,48),'b':(92,104,88,48),'c':(0,58,91,44),'d':(92,58,88,44),'e':(0,0,91,57),'f':(92,0,88,57)})

def supp5():
 f=canvas()
 header(f,'a','Training ΔFC: all three triad components',2,154)
 t=read('triad_component_group_effects');t=t[t.layer=='dL'].set_index('edge').loc[TRI].reset_index()
 a=axes(f,29,112,44,30);forest(a,t,labels=[e.replace('-','–') for e in t.edge],pc='P',color=HIGH,xlim=(-.02,.37),ticks=[0,.1,.2,.3]);a.set_xlabel('High − low training ΔFC\n(Fisher z, 95% CI)',labelpad=3)
 source('Supplementary_Fig5_Extended_Checksa',t)
 header(f,'b','All 12 cortical–striatal baseline connections',94,154)
 t=read('baseline_candidates_12');a=axes(f,121,41,43,100)
 for lo,hi in [(8.5,11.5),(2.5,5.5)]:a.axhspan(lo,hi,color='#F5F5F4',lw=0,zorder=-2)
 for y in [8.5,5.5,2.5]:a.axhline(y,color='#DDDDDD',lw=.5,zorder=-1)
 forest(a,t,xlim=(-.32,.13),ticks=[-.3,-.2,-.1,0,.1]);a.set_xlabel('High − low pre-training FC\n(Fisher z, 95% CI)',labelpad=3)
 source('Supplementary_Fig5_Extended_Checksb',t)
 header(f,'c','Direct contrasts of baseline group effects',2,83)
 t=read('direct_specificity_contrasts');a=axes(f,36,43,37,26)
 forest(a,t,labels=['ACC–DMS\nminus ACC–NAc','ACC–DMS\nminus ACC–DLS'],xlim=(-.20,.18),ticks=[-.1,0,.1],color=LOW)
 a.set_xlabel('Difference between group effects\n(Fisher z, 95% CI)',labelpad=3)
 source('Supplementary_Fig5_Extended_Checksc',t)
 textmm(f,90,13,'Points and bars: adjusted effects and 95% CIs · P values: two-sided, unadjusted wild bootstrap',ha='center',fontsize=6.5)
 textmm(f,90,8,'Filled symbols: nominal P < 0.05 · Open symbols: P ≥ 0.05',ha='center',fontsize=6.5)
 save(f,'Supplementary_Fig5_Extended_Checks',{'a':(0,91,91,66),'b':(92,25,88,132),'c':(0,25,91,62)})

if __name__=='__main__':
 verify()
 selected=sys.argv[1:] or ['Fig4','Fig5','Supplementary_Fig5_Extended_Checks']
 for name in selected:
  {'Fig4':fig4,'Fig5':fig5,'Supplementary_Fig5_Extended_Checks':supp5}[name]()
  print('Exported',name,flush=True)
 (HERE/'review/numerical_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
 (HERE/'review/text_bounds.json').write_text(json.dumps(TEXT_AUDIT,ensure_ascii=False,indent=2))
 (HERE/'review/figure_metadata.json').write_text(json.dumps(META,ensure_ascii=False,indent=2))
 print('Checks:',len(checks),'Text outside canvas:',sum(t['outside'] for f in TEXT_AUDIT for t in f['text']),flush=True)
