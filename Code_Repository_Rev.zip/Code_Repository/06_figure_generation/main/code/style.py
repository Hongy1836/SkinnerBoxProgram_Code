"""Publication style and exact-scale exports; no statistical mutations."""
from pathlib import Path
import os,json
HERE=Path(__file__).resolve().parents[1]
for folder in ['figures/panels','source_data','review']: (HERE/folder).mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR']=str(HERE/'review/mpl_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox
from matplotlib.text import Text
from scipy import stats
LOW='#2B5C8F';HIGH='#C84B31';DARK='#333333';GRAY='#888888'
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':8,'axes.titlesize':8,'axes.titleweight':'normal','xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'axes.linewidth':.75,'xtick.major.width':.75,'ytick.major.width':.75,'xtick.major.size':3,'ytick.major.size':3,'xtick.direction':'out','ytick.direction':'out','lines.linewidth':1.,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'text.color':DARK,'axes.labelcolor':DARK,'xtick.color':DARK,'ytick.color':DARK,'legend.frameon':False,'axes.unicode_minus':True,'savefig.facecolor':'white'})
META=[];BOUNDS=[];PANEL_BOUNDS=[]
def source(name,df):
 df.to_csv(HERE/'source_data'/f'{name}.csv',index=False,float_format='%.17g')
 return df

def animal_points(ax,x,y,groups,batches,size=16):
 x=np.asarray(x);y=np.asarray(y)
 for g,col in [(0,LOW),(1,HIGH)]:
  for b,m in [('B1','s'),('B2','o')]:
   sel=(np.asarray(groups)==g)&(np.asarray(batches)==b)
   ax.scatter(x[sel],y[sel],s=size,marker=m,facecolors='white' if g==0 else col,edgecolors=col,alpha=1 if g==0 else .85,lw=.75,zorder=4)

def key(fig,y=.012,group=True,batch=True):
 handles=[]
 if group:handles += [Line2D([],[],marker='o',ls='',mfc='white',mec=LOW,ms=4,label='Low earners (n = 13)'),Line2D([],[],marker='o',ls='',mfc=HIGH,mec=HIGH,ms=4,label='High earners (n = 18)')]
 if batch:handles += [Line2D([],[],marker='s',ls='',mfc='none',mec=DARK,ms=4,label='Batch 1 (n = 10)'),Line2D([],[],marker='o',ls='',mfc='none',mec=DARK,ms=4,label='Batch 2 (n = 21)')]
 fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.51,y),ncol=len(handles),handletextpad=.35,columnspacing=1.25,borderaxespad=0)

def zero(ax,orientation='h',value=0):
 (ax.axhline if orientation=='h' else ax.axvline)(value,color=GRAY,ls=':',lw=.75,zorder=0)

def save(fig,name,cells,panel_keys=None):
 apply_p_style(fig);record_axes(fig,name,HERE/"review")
 """Export the assembled figure and its exact physical panel cells."""
 labels=[]
 for letter,(x0,y0,x1,y1) in cells.items():labels.append(fig.text(x0+.012,y1-.018,letter,fontsize=10,fontweight='bold',va='top',ha='left'))
 fig.canvas.draw()
 # Hide locator-generated ticks outside the actual limits before crop auditing.
 for axis in fig.axes:
  if not axis.axison:
   axis.set_xticks([]);axis.set_yticks([])
  for aa,limits in [(axis.xaxis,axis.get_xlim()),(axis.yaxis,axis.get_ylim())]:
   for tick in aa.get_major_ticks():
    tick.label1.set_visible(min(limits)<=tick.get_loc()<=max(limits));tick.label2.set_visible(False)
 fig.canvas.draw();rend=fig.canvas.get_renderer()
 for obj in fig.findobj(match=lambda a:isinstance(a,Text)):
  if not obj.get_visible() or not obj.get_text().strip():continue
  bb=obj.get_window_extent(rend)
  if bb.x0<-.5 or bb.y0<-.5 or bb.x1>fig.bbox.x1+.5 or bb.y1>fig.bbox.y1+.5:BOUNDS.append(dict(figure=name,text=obj.get_text(),bbox=list(bb.extents)))
 for ext in ['pdf','svg','png']:
  fig.savefig(HERE/'figures'/f'{name}.{ext}',dpi=600)
 fig.savefig(HERE/'review'/f'{name}_preview.png',dpi=160)
 axes=fig.axes[:];texts=fig.texts[:];legends=fig.legends[:]
 for letter,(x0,y0,x1,y1) in cells.items():
  bbox=Bbox.from_extents(x0*fig.get_figwidth(),y0*fig.get_figheight(),x1*fig.get_figwidth(),y1*fig.get_figheight())
  for ax in axes:
   p=ax.get_position();ax.set_visible(x0<=(p.x0+p.x1)/2<x1 and y0<=(p.y0+p.y1)/2<y1)
  for tx in texts:
   txpos=tx.get_position()
   tx.set_visible((tx in labels and tx.get_text()==letter) or (tx not in labels and tx.get_gid()!='figure_footer' and x0<=txpos[0]<x1 and y0<=txpos[1]<y1))
  for lg in legends:lg.set_visible(False)
  # Expand a panel cell if a tick/title crosses its nominal boundary; no clipping.
  fig.canvas.draw();renderer=fig.canvas.get_renderer();pieces=[bbox.transformed(fig.dpi_scale_trans)]
  pieces.extend(a.get_tightbbox(renderer) for a in axes if a.get_visible() and a.get_tightbbox(renderer) is not None)
  pieces.extend(t.get_window_extent(renderer) for t in texts if t.get_visible())
  bbox=Bbox.union(pieces).transformed(fig.dpi_scale_trans.inverted())
  panel_key=None
  if panel_keys and letter in panel_keys:
   handles,ncol=panel_keys[letter]
   center=(bbox.x0+bbox.x1)/2/fig.get_figwidth()
   bottom=bbox.y0/fig.get_figheight()-.008
   panel_key=fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(center,bottom),ncol=ncol,handletextpad=.35,columnspacing=1.25,borderaxespad=0)
   fig.canvas.draw()
   key_bbox=panel_key.get_window_extent(fig.canvas.get_renderer()).transformed(fig.dpi_scale_trans.inverted())
   bbox=Bbox.union([bbox,key_bbox.padded(.025)])
  bbox=bbox.padded(.04)
  for ext in ['pdf','svg','png']:fig.savefig(HERE/'figures/panels'/f'{name}{letter}.{ext}',dpi=600,bbox_inches=bbox,pad_inches=0)
  if panel_key is not None:panel_key.remove()
  for ax in axes:ax.set_visible(True)
  for tx in texts:tx.set_visible(True)
  for lg in legends:lg.set_visible(True)
 META.append(dict(figure=name,width_mm=fig.get_figwidth()*25.4,height_mm=fig.get_figheight()*25.4,panels=list(cells),png_dpi=600))
 plt.close(fig)

def canvas(height=150):return plt.figure(figsize=(180/25.4,height/25.4))
def cells_grid(rows,cols,top=1,bottom=0):
 return {chr(97+r*cols+c):(c/cols,bottom+(top-bottom)*(rows-1-r)/rows,(c+1)/cols,bottom+(top-bottom)*(rows-r)/rows) for r in range(rows) for c in range(cols)}

def trajectory(ax,t,colname,by_group=True):
 piv=t.pivot(index='animal',columns='phase',values=colname).loc[:,list('BLS')]
 for row in piv.to_numpy():ax.plot(range(3),row,color='#CCCCCC',lw=.6,alpha=1,zorder=1)
 summaries=[]
 groups=[(0,LOW,'o','--'),(1,HIGH,'o','-')] if by_group else [(-1,'#222222','o','-')]
 for g,col,m,ls in groups:
  ids=t.loc[t.group==g,'animal'].unique() if g>=0 else piv.index
  a=piv.loc[ids].to_numpy();mean=a.mean(0);sem=stats.sem(a,axis=0)
  ax.errorbar(range(3),mean,yerr=sem,color=col,marker=m,mfc='white' if g==0 else col,mec=col,ls=ls,ms=4,lw=1.8,capsize=2,zorder=5,label=('Low' if g==0 else 'High') if g>=0 else 'Mean ± SEM')
  summaries.extend(dict(group=g,phase=p,mean=mean[i],SEM=sem[i],n=len(a)) for i,p in enumerate('BLS'))
 ax.set_xticks(range(3),['Before\ntraining','After\ntraining','After\npunishment']);ax.margins(x=.13,y=.12)
 return summaries

def dot_groups(ax,t,colname,ylabel):
 for g,col in [(0,LOW),(1,HIGH)]:
  rows=t[t.group==g];x=g+np.linspace(-.17,.17,len(rows));v=rows[colname].to_numpy()
  animal_points(ax,x,v,rows.group,rows.batch,size=20)
  ax.plot([g-.22,g+.22],[v.mean()]*2,color=col,lw=1.8,zorder=5)
  ax.errorbar(g,v.mean(),yerr=stats.sem(v),fmt='none',color=col,lw=1.2,capsize=3,zorder=5)
 ax.set_xticks([0,1],['Low earners\n(n = 13)','High earners\n(n = 18)']);ax.set_xlim(-.5,1.5);ax.set_ylabel(ylabel);ax.margins(y=.17)

from typography import apply_p_style,record_axes
