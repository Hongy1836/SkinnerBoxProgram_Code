"""Regenerate eight study figures from immutable numerical tables.
Run: python code/build_figures.py [Fig2 Fig3 ... Supplementary_Fig4]
No model retraining, P-value estimation, participant exclusion or ROI relocation.
"""
from style import *
from anatomy import brain,NODES,REF,MZ,POS
import pandas as pd
from scipy import stats
from matplotlib.patches import Rectangle
from matplotlib.colors import TwoSlopeNorm
from sklearn.metrics import balanced_accuracy_score,roc_auc_score
import shutil,sys,hashlib
INPUT=HERE/'inputs'
def read(name):return pd.read_csv(INPUT/(name+'.csv'))
def ax(fig,pos,title=None):
 a=fig.add_axes(pos)
 if title:a.set_title(title,pad=7)
 return a

def fit_scatter(a,t,ycol,title,ylabel,name,k,groups_only=False):
 x=t.FC_residual.to_numpy();y=t[ycol].to_numpy()
 r=t['partial_r' if 'partial_r' in t else 'r'].iloc[0];p=t.P.iloc[0]
 np.testing.assert_allclose(np.corrcoef(x,y)[0,1],r,atol=1e-12)
 # The recorded least-squares line is unchanged. New CI uses the full model's df.
 slope,intercept=np.polyfit(x,y,1);xx=np.linspace(x.min(),x.max(),100);yy=slope*xx+intercept
 df=len(x)-k-2;sse=np.sum((y-(slope*x+intercept))**2);s2=sse/df
 half=stats.t.ppf(.975,df)*np.sqrt(s2*(1/len(x)+(xx-x.mean())**2/np.sum((x-x.mean())**2)))
 a.fill_between(xx,yy-half,yy+half,color='#D7D7D7',alpha=.5,lw=0,zorder=1)
 a.plot(xx,yy,color='#454545',lw=1,zorder=2)
 if groups_only:
  for g,col in [(0,LOW),(1,HIGH)]:
   mask=t.group.to_numpy()==g
   a.scatter(x[mask],y[mask],s=18,marker='o',facecolors='none' if g==0 else col,edgecolors=col,alpha=1 if g==0 else .88,lw=1.2 if g==0 else .6,zorder=4)
 else:animal_points(a,x,y,t.group,t.batch)
 a.margins(x=.11,y=.28);a.text(.03,.98,f'r = {r:.3f}\nP = {p:.4f}',transform=a.transAxes,va='top',fontsize=6.5)
 a.set_title(title,pad=5);a.set_xlabel('Adjusted FC\n(Fisher z)' if 'Δ' not in title else 'Adjusted ΔFC\n(Fisher z)');a.set_ylabel(ylabel,fontsize=7.5)
 source(name,t);source(name+'_fit',pd.DataFrame(dict(x=xx,fit=yy,CI_low=yy-half,CI_high=yy+half,df=df,nuisance_covariates=k,slope=slope,intercept=intercept)))

def forest(a,t,title,showp=True,anatomical_order=False):
 if anatomical_order:
  order=['DLS-M1','M1-AI','DLS-AI','NAc-VTA','NAc-M1','NAc-DLS','NAc-AI','DLS-VTA','M1-VTA','AI-VTA','NAc-LHA','DLS-LHA','M1-LHA','AI-LHA','VTA-LHA']
  t=t.set_index('feature').loc[order].reset_index()
  a.axhspan(-.5,4.5,color='#F1F2F3',zorder=-2,lw=0)
  a.axhline(4.5,color='#B8B8B8',lw=.5,zorder=-1)
 else:t=t.sort_values('r',ascending=False).copy()
 a.set_title(title,pad=5)
 for j,r in enumerate(t.itertuples()):
  y=len(t)-1-j;col=HIGH if r.r>0 else LOW
  if r.P>=.05:col=GRAY
  a.errorbar(r.r,y,xerr=[[r.r-r.CI_low],[r.CI_high-r.r]],fmt='o',mfc=col if r.P<.05 else 'white',mec=col,ecolor=col,ms=3.5,lw=.75,capsize=1.5)
  if showp:a.text(1.03,y,f'{r.P:.4f}',transform=a.get_yaxis_transform(),ha='left',va='center',fontsize=6.5)
 zero(a,'v');a.set_yticks(range(len(t)-1,-1,-1),t.feature.str.replace('-','–'));a.tick_params(axis='y',length=0,pad=3);a.set_xlim(-.79,.87);a.set_ylim(-.75,len(t)-.2);a.set_xticks([-.5,0,.5]);a.set_xlabel('Partial r (95% CI)')
 if showp:a.text(1.03,1.015,'P',transform=a.transAxes,fontsize=6.5,ha='left')
 return t

def group_key(f,y=.965,lines=False):
 handles=[Line2D([],[],color=col,marker='o',ls=ls if lines else '',mfc='white' if g==0 else col,mec=col,ms=4,lw=1.3,label=f'{label} earners (n = {n})') for g,col,ls,label,n in [(0,LOW,'--','Low',13),(1,HIGH,'-','High',18)]]
 f.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,y),ncol=2,handlelength=2.2,handletextpad=.6,columnspacing=3,borderaxespad=0)

def fig2():
 f=plt.figure(figsize=(185/25.4,175/25.4))
 cells={'a':(0,.60,.33,.95),'b':(.33,.60,.66,.95),'c':(.66,.60,1,.95),
        'd':(0,.045,.355,.60),'e':(.355,.315,.6775,.60),'f':(.6775,.315,1,.60),
        'g':(.355,.04,.6775,.315),'h':(.6775,.04,1,.315)}
 for j in range(2):
  a=ax(f,[.065+j*.33,.697,.235,.215]);t=read('Fig2'+chr(97+j));z=np.full((13,13),np.nan)
  for r in t.itertuples():
   i,k=[NODES.index(n) for n in r.edge.split('-')];z[i,k]=z[k,i]=r.change
  im=a.pcolormesh(np.arange(14)-.5,np.arange(14)-.5,z,cmap='RdBu_r',vmin=-.18,vmax=.18,shading='flat',edgecolors='none');a.set_aspect('equal');a.set_ylim(12.5,-.5);a.set_xlim(-.5,12.5)
  for sp in a.spines.values():sp.set_visible(False)
  for r in t[t.NBS_component_member].itertuples():
   i,k=[NODES.index(n) for n in r.edge.split('-')];a.add_patch(Rectangle((min(i,k)-.5,max(i,k)-.5),1,1,fill=False,ec='#222222',lw=1.5))
  a.set_xticks(range(13),NODES,rotation=90);a.set_yticks(range(13),NODES);a.tick_params(length=0,pad=2)
  a.set_title('After − before training' if j==0 else 'After punishment −\nafter training',pad=6,fontsize=7.5)
  ca=f.add_axes([.065+j*.33,.644,.235,.010]);cb=f.colorbar(im,cax=ca,orientation='horizontal');cb.solids.set_rasterized(False);cb.set_ticks([-.18,0,.18]);cb.set_label('Adjusted ΔFC (Fisher z)',fontsize=7,labelpad=1);cb.outline.set_visible(False)
  source('Fig2'+chr(97+j),t)
 t=read('Fig2c');a=f.add_axes([.67,.69,.325,.25]);brain(a,['ACC','PrL','NAc','AI','S2'],t.edge,all_nodes=True,hub='NAc',edge_weights=t.set_index('edge').change.to_dict());a.set_title('Post-punishment increase',pad=1,fontsize=7.5)
 a.text(.5,-.07,'Component P = 0.0049\nAdjusted P = 0.0196',transform=a.transAxes,ha='center',va='top',fontsize=6.5);source('Fig2c',t)
 z=np.load(HERE/'inputs/frozen_data13.npz',allow_pickle=True)
 for letter,edge in [('g','NAc-AI'),('h','PrL-S2')]:
  k=list(z['edge_names']).index(edge)
  t=pd.DataFrame([dict(animal=animal,batch=z['batch'][i],group=z['labels'][i],phase=p,FC=z[p][i,k]) for i,animal in enumerate(z['animals']) for p in 'BLS'])
  t.to_csv(INPUT/f'Fig2{letter}.csv',index=False,float_format='%.17g')
 positions=[[.080,.205,.245,.285],[.425,.393,.215,.170],[.755,.393,.215,.170],[.425,.115,.215,.170],[.755,.115,.215,.170]]
 titles=['Four-edge component mean','ACC–NAc','PrL–NAc','NAc–AI','PrL–S2']
 all_values=[]
 for j,letter in enumerate('defgh'):
  name='Fig2'+letter;t=read(name);value='component_mean_FC' if j==0 else 'FC';all_values.extend(t[value])
  a=ax(f,positions[j],titles[j]);summary=trajectory(a,t,value,by_group=True)
  a.set_ylim(-.4,.7);a.set_yticks([-.2,0,.2,.4,.6]);a.set_ylabel('FC (Fisher z)',fontsize=7,labelpad=2)
  a.tick_params(axis='x',labelsize=6.5,pad=3);source(name,t);source(name+'_summary',pd.DataFrame(summary))
  if j==0:
   pooled=t.pivot(index='animal',columns='phase',values=value).loc[:,list('BLS')].to_numpy()
   pooled_mean=pooled.mean(axis=0);pooled_sem=stats.sem(pooled,axis=0)
   overall=a.errorbar(range(3),pooled_mean,yerr=pooled_sem,color='#000000',ls='-',lw=1.1,
     marker='D',ms=3.2,mfc='#000000',mec='#000000',capsize=1.8,zorder=4,label='All mice (n = 31)')
   a.legend(handles=[overall],loc='upper left',bbox_to_anchor=(.015,.76),fontsize=6.5,
     handlelength=1.6,handletextpad=.6,borderaxespad=0)
   source(name+'_pooled_summary',pd.DataFrame(dict(phase=list('BLS'),mean=pooled_mean,SEM=pooled_sem,n=len(pooled))))
   a.text(.03,.97,'26/31 mice increased\nafter punishment',transform=a.transAxes,ha='left',va='top',fontsize=6.5)
   a.text(.03,.81,'Mean ± SEM',transform=a.transAxes,ha='left',va='bottom',fontsize=6.5)
 assert min(all_values)>-.4 and max(all_values)<.7
 (HERE/'review/Fig2_range.json').write_text(json.dumps(dict(min=min(all_values),max=max(all_values),ylim=[-.4,.7],yticks=[-.2,0,.2,.4,.6]),indent=2))
 group_key(f,y=.975,lines=True);save(f,'Fig2',cells)

def fig3():
 f=canvas(155);cells={'a':(0,.44,.5,.94),'b':(.5,.44,1,.94),**{chr(99+j):(j/4,0,(j+1)/4,.44) for j in range(4)}}
 tab=read('Fig3b');a=f.add_axes([.025,.545,.46,.33]);brain(a,['DLS','M1','AI','NAc','VTA','LHA'],tab.feature,signed={r.feature:(r.r,r.P) for r in tab.itertuples()},functional=True);a.set_title('Action, reward and internal state',pad=1)
 a.text(.5,-.025,'6 ROIs · all 15 connections',transform=a.transAxes,ha='center',va='top',fontsize=7)
 from matplotlib.patches import Patch
 hh=[Patch(fc=fc,ec=ec,label=lab) for fc,ec,lab in [('#F3C68F','#B87A3D','Feeding / Internal state'),('#9ED2C6','#3E7C6E','Action execution'),('#B8B5E1','#5C5899','Motivational control')]]
 a.legend(handles=hh,loc='upper center',bbox_to_anchor=(.5,-.135),ncol=1,fontsize=6.5,handlelength=1.1,labelspacing=.3,frameon=False)
 a=ax(f,[.64,.495,.26,.37]);forest(a,tab,'Food earned',anatomical_order=True);source('Fig3b',tab);source('Fig3a',tab)
 for j,e in enumerate(['DLS–M1','M1–AI','NAc–VTA','NAc–M1']):
  name='Fig3'+chr(99+j);t=read(name);a=ax(f,[.085+j*.245,.15,.165,.235]);fit_scatter(a,t,'behavior_residual',e,'Adjusted food earned\n(pellets/session)' if j==0 else '',name,2,groups_only=True)
  if j==3:a.texts[0].set_x(.97);a.texts[0].set_ha('right')
  a.set_xlim(-.42,.42);a.set_xticks([-.4,-.2,0,.2,.4]);a.set_ylim(-14,23);a.set_yticks([-10,0,10,20]);a.tick_params(axis='x',labelsize=6.5)
 group_key(f,y=.96)
 f.text(.5,.035,'Network edges: solid, nominal P < 0.05; dashed, P ≥ 0.05',ha='center',va='bottom',fontsize=6.5,gid='figure_footer')
 edge_handles=[Line2D([],[],color=DARK,lw=1,label=r'Nominal $\mathit{p}$ < 0.05'),Line2D([],[],color=GRAY,lw=1,ls='--',label=r'$\mathit{p}$ ≥ 0.05')]
 save(f,'Fig3',cells,panel_keys={'a':(edge_handles,1)})

def fig4():
 f=canvas(150);cells=cells_grid(2,2,top=.94)
 a=ax(f,[.11,.56,.32,.245],'ACC–DMS before training');t=read('Fig4a');dot_groups(a,t,'FC','FC (Fisher z)');source('Fig4a',t)
 a.text(.02,.98,'Adjusted difference = −0.126\nP = 0.0256',transform=a.transAxes,va='top',fontsize=6.5)
 b=f.add_axes([.28,.835,.19,.10]);brain(b,['ACC','DMS'],['ACC-DMS'],mini=True)
 a=ax(f,[.62,.56,.32,.245],'DLS–M1–AI');t=read('Fig4b');s=trajectory(a,t,'mean_FC');a.set_ylabel('Mean network FC (Fisher z)');a.text(.02,.98,'Group × stage\nP = 0.0028',transform=a.transAxes,va='top',fontsize=6.5);source('Fig4b',t);source('Fig4b_summary',pd.DataFrame(s))
 b=f.add_axes([.78,.835,.19,.10]);brain(b,['DLS','M1','AI'],['DLS-M1','DLS-AI','M1-AI'],mini=True)
 a=ax(f,[.11,.12,.32,.25],'DLS–M1–AI across training');t=read('Fig4c');dot_groups(a,t,'delta_FC','Network ΔFC (Fisher z)');zero(a);a.text(.02,.98,'Adjusted difference = 0.175\nP = 0.0020',transform=a.transAxes,va='top',fontsize=6.5);source('Fig4c',t)
 a=ax(f,[.71,.145,.215,.22],'Starting-state sensitivity');t=read('Fig4d')
 for j,r in enumerate(t.itertuples()):
  a.errorbar(r.effect,1-j,xerr=[[r.effect-r.CI_low],[r.CI_high-r.effect]],fmt='o' if j==0 else 's',mfc=DARK if j==0 else 'white',mec=DARK,ecolor=DARK,capsize=2,ms=4,lw=.85)
  a.text(1.02,1-j,f'P = {r.P:.4f}',transform=a.get_yaxis_transform(),va='center',ha='left',fontsize=6.5)
 zero(a,'v');a.set_yticks([1,0],['Batch + motion','+ Starting FC']);a.tick_params(axis='y',length=0,pad=3);a.set_xlim(-.07,.29);a.set_ylim(-.65,1.65);a.set_xticks([0,.1,.2]);a.set_xlabel('High − low ΔFC\n(Fisher z; 95% CI)');source('Fig4d',t)
 key(f);save(f,'Fig4',cells)

def fig5():
 f=canvas(155);cells={'a':(0,.70,.5,.96),'b':(.5,.70,1,.96),'c':(0,.365,.5,.70),'d':(.5,.365,1,.70),'e':(0,0,.5,.365),'f':(.5,0,1,.365)}
 for j in range(2):
  a=f.add_axes([.015+j*.5,.75,.23,.19]);brain(a,['ACC','DMS'] if j==0 else ['DLS','M1','AI'],['ACC-DMS'] if j==0 else ['DLS-M1','DLS-AI','M1-AI'],mini=True)
  a.set_title('Before-training FC' if j==0 else 'Change across training',pad=0)
  a=f.add_axes([.25+j*.5,.745,.235,.20]);a.axis('off')
  labels=['1 connection' if j==0 else '3-edge mean','Training-only motion fit','Centroids + tuned threshold','Held-out group label']
  for i,lab in enumerate(labels):
   y=.92-i*.27;a.text(.5,y,lab,ha='center',va='center',fontsize=6.5)
   if i<3:a.annotate('',xy=(.5,y-.18),xytext=(.5,y-.07),arrowprops=dict(arrowstyle='->',lw=.65,color=DARK))
  source('Fig5'+chr(97+j),read('Fig5'+chr(97+j)))
 for k,metric in enumerate(['balanced_accuracy','auc']):
  a=ax(f,[.15+k*.50,.425,.31,.22]);t=read('Fig5'+chr(99+k))
  for j,model in enumerate(t.model.unique()):
   rows=t[t.model==model]
   for h,scheme in enumerate(['LOO','B2toB1']):
    r=rows[rows.scheme==scheme].iloc[0];y=3-j*2-h;col=LOW if h==0 else HIGH
    a.scatter(r[metric],y,s=21,marker='o' if h==0 else 's',fc=col if h==0 else 'white',ec=col,lw=.85,zorder=3)
    val=f'{100*r[metric]:.1f}% · {int(r.correct)}/{int(r.n)} correct' if k==0 else f'{r[metric]:.3f}'
    a.text(1.01,y+.24,val,ha='right',va='center',fontsize=6.5)
  zero(a,'v',.5);a.set_xlim(.45,1.015);a.set_ylim(-.65,3.65);a.set_yticks([2.5,.5],['ACC–DMS','DLS–M1–AI']);a.tick_params(axis='y',length=0,pad=3);a.set_xlabel('Balanced accuracy' if k==0 else 'ROC AUC');a.set_xticks([.5,.75,1]);source('Fig5'+chr(99+k),t)
 # All marker and validation keys are collected below the assembled figure.
 f.text(.5,.71,'Cohort-selected inputs · classifier fitting within training partitions',ha='center',fontsize=6.5,color=DARK)
 for j in range(2):
  name='Fig5'+chr(101+j);t=read(name);np.testing.assert_array_equal((t.decision_margin>=0).astype(int),t.prediction)
  a=ax(f,[.12+j*.5,.13,.34,.18],'ACC–DMS · batch 1' if j==0 else 'DLS–M1–AI · batch 1')
  for i,r in enumerate(t.itertuples()):
   col=LOW if r.label==0 else HIGH
   # Every test animal is Batch 1, so all use squares; fill identifies group.
   a.scatter(i,r.decision_margin,s=21,marker='s',fc='white' if r.label==0 else col,ec=col,lw=.8,zorder=3)
   if r.label!=r.prediction:a.scatter(i,r.decision_margin,s=65,marker='o',fc='none',ec='#444444',lw=.8,zorder=2)
  zero(a);a.set_xlim(-.7,9.7);a.set_xticks(range(10),range(1,11));a.set_xlabel('Test animal (display order)');a.set_ylabel('Decision margin');a.margins(y=.3);a.text(.98,.98,'Predicted high',transform=a.transAxes,ha='right',va='top',fontsize=6.5);a.text(.98,.025,'Predicted low',transform=a.transAxes,ha='right',va='bottom',fontsize=6.5)
  a.text(.5,1.24,('Low: 6/7 · High: 3/3' if j==0 else 'Low: 4/7 · High: 3/3'),transform=a.transAxes,ha='center',fontsize=6.5)
  source(name,t)
 validation_handles=[Line2D([],[],marker='o',ls='',mfc=LOW,mec=LOW,ms=4,label='c, d: LOO (n = 31)'),Line2D([],[],marker='s',ls='',mfc='white',mec=HIGH,ms=4,label='c, d: Batch 2 → 1 (21 → 10 mice)')]
 group_handles=[Line2D([],[],marker='s',ls='',mfc='white',mec=LOW,ms=4,label='e, f: Low earners'),Line2D([],[],marker='s',ls='',mfc=HIGH,mec=HIGH,ms=4,label='e, f: High earners'),Line2D([],[],marker='o',ls='',mfc='none',mec='#444444',ms=6,label='e, f: Misclassified')]
 for handles,y in [(validation_handles,.037),(group_handles,.007)]:
  f.legend(handles=handles,loc='lower center',bbox_to_anchor=(.51,y),ncol=len(handles),handletextpad=.35,columnspacing=1.25,borderaxespad=0)
 panel_validation=[Line2D([],[],marker='o',ls='',mfc=LOW,mec=LOW,ms=4,label='LOO (n = 31)'),Line2D([],[],marker='s',ls='',mfc='white',mec=HIGH,ms=4,label='Batch 2 → 1 (21 → 10 mice)')]
 panel_groups=[Line2D([],[],marker='s',ls='',mfc='white',mec=LOW,ms=4,label='Low earners'),Line2D([],[],marker='s',ls='',mfc=HIGH,mec=HIGH,ms=4,label='High earners'),Line2D([],[],marker='o',ls='',mfc='none',mec='#444444',ms=6,label='Misclassified')]
 save(f,'Fig5',cells,panel_keys={'c':(panel_validation,1),'d':(panel_validation,1),'e':(panel_groups,3),'f':(panel_groups,3)})

def supp1():
 f=canvas(120);cells=cells_grid(1,2,top=.94)
 tests=pd.read_csv(INPUT/'behavior_group_tests.csv')
 for j,(beh,title,yl) in enumerate([('E03','Late-training consumption','Food consumed (pellets/session)'),('E11','Punishment suppression','Rewarded-response suppression')]):
  t=read('SuppFig1'+chr(97+j));a=ax(f,[.12+j*.5,.22,.32,.53],title);dot_groups(a,t,'value',yl);r=tests[(tests.behavior==beh)&(~tests.adjust_training)].iloc[0];a.text(.03,.98,f'Adjusted difference = {r.effect:.3f}\nP = {r.P:.4f}',transform=a.transAxes,fontsize=6.5,va='top');source('Supplementary_Fig1'+chr(97+j),t)
 key(f);save(f,'Supplementary_Fig1',cells)

def supp2():
 import nibabel as nib
 f=canvas(150);cells=cells_grid(2,3);im=nib.load(REF/'group_meanEPI_93scans.nii');bg=im.get_fdata();np.testing.assert_array_equal(im.affine,MZ['affine'])
 for j,n in enumerate(['ACC','DMS','DLS','M1','AI','NAc']):
  r,col=divmod(j,3);a=f.add_axes([.025+col/3,.55-r*.5,.30,.36]);mask=MZ[n];ix=int(np.argmax(mask[:mask.shape[0]//2].sum((1,2))));a.imshow(bg[ix].T,origin='lower',cmap='gray',vmin=0,vmax=np.percentile(bg[bg>0],99),interpolation='nearest');a.contour(mask[ix].T.astype(float),levels=[.5],colors=[HIGH],linewidths=.9)
  a.set_xlim(51,2);a.set_ylim(1,29);a.axis('off');a.set_title(f'{n} · sagittal slice {ix}',pad=5)
  for x,y,l in [(.03,.5,'A'),(.97,.5,'P'),(.5,.95,'D'),(.5,.03,'V')]:a.text(x,y,l,transform=a.transAxes,color='white',ha='center',va='center',fontsize=7,bbox=dict(fc='black',ec='none',pad=.4))
  a.plot([45,45-1/.3],[3,3],color='white',lw=1.5);a.text(45-1/.6,5,'1 mm',color='white',fontsize=6.5,ha='center');source('Supplementary_Fig2'+chr(97+j),read('SuppFig2'+chr(97+j)))
 save(f,'Supplementary_Fig2',cells)

def supp3():
 f=canvas(120);cells=cells_grid(1,3,top=.78)
 for j,e in enumerate(['DLS–M1','M1–AI','NAc–VTA']):
  t=read('SuppFig3'+chr(97+j));a=ax(f,[.08+j/3,.23,.235,.48]);fit_scatter(a,t,'active_residual',e,'Adjusted active presses\n(per session)' if j==0 else '', 'Supplementary_Fig3'+chr(97+j),2,groups_only=True)
  a.set_ylim(-25,38);a.set_yticks([-20,-10,0,10,20,30])
 group_key(f,y=.88);save(f,'Supplementary_Fig3',cells)

def supp4():
 f=canvas(155);cells=cells_grid(2,3,top=.94)
 names=['DLS–M1','M1–AI','NAc–VTA','NAc–VTA ΔFC','NAc–VTA ΔFC · start adjusted']
 for j,title in enumerate(names):
  r,col=divmod(j,3);a=ax(f,[.078+col/3,.61-r*.45,.233,.245]);name='Supplementary_Fig4'+chr(97+j);t=read(name);fit_scatter(a,t,'behavior_residual',title,('Adjusted food consumed' if j<3 else 'Adjusted consumption gain')+'\n(pellets/session)' if col==0 else '',name,3 if j<3 else 2 if j==3 else 4)
 a=ax(f,[.817,.115,.115,.31]);tab=read('Supplementary_Fig4f');forest(a,tab,'All 15 connections',showp=False);source('Supplementary_Fig4f',tab)
 key(f);save(f,'Supplementary_Fig4',cells)

FUNCTIONS={'Fig2':fig2,'Fig3':fig3,'Fig4':fig4,'Fig5':fig5,'Supplementary_Fig1':supp1,'Supplementary_Fig2':supp2,'Supplementary_Fig3':supp3,'Supplementary_Fig4':supp4}
if __name__=='__main__':
 selected=sys.argv[1:] or list(FUNCTIONS)
 for name in selected:
  print('Building',name,flush=True);FUNCTIONS[name]()
 (HERE/'review'/('figure_manifest_'+('_'.join(selected) if len(selected)<8 else 'all')+'.json')).write_text(json.dumps(META,indent=2))
 (HERE/'review'/('text_bounds_'+('_'.join(selected) if len(selected)<8 else 'all')+'.json')).write_text(json.dumps(BOUNDS,indent=2))
 print('Finished',len(META),'figures; outside-canvas text:',BOUNDS,flush=True)
