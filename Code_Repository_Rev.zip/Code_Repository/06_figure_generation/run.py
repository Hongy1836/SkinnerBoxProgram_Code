from pathlib import Path
import subprocess,sys,shutil
R=Path(__file__).resolve().parent;O=R.parent/'outputs/figures';O.mkdir(parents=True,exist_ok=True)
for engine,names,mapping in [('main',['Fig2','Fig3','Supplementary_Fig2'],{'Supplementary_Fig2':'FigS5'}),('classifiers',['Fig4','Fig5'],{}),('supplementary',['Supplementary_Fig3','Supplementary_Fig4'],{'Supplementary_Fig3':'FigS6','Supplementary_Fig4':'FigS7'}),('extended',['Supplementary_Fig5_Extended_Checks'],{'Supplementary_Fig5_Extended_Checks':'FigS8'})]:
 for folder in ['source_data','figures/panels','review']:(R/engine/folder).mkdir(parents=True,exist_ok=True)
 subprocess.run([sys.executable,str(R/engine/'code/build_figures.py'),*names],check=True)
 for name in names:
  for ext in ['pdf','png','svg']:
   f=R/engine/'figures'/(name+'.'+ext)
   if f.exists():shutil.copyfile(f,O/(mapping.get(name,name)+'.'+ext))
