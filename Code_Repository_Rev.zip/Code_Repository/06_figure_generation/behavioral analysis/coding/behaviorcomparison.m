%% ����С����Ϊ���죺�ĺ�һ 2x2 ͼ����ƽű� (Y��̶���)
clear; clc; close all;

%% 1. ���������������Ϣ
filename_cluster = 'Learning_Clustering_Results_4Features.xlsx';
filename_data = 'SIA_20260803.xlsx';

% ��ȡ����
cluster_table = readtable(filename_cluster, 'Sheet', 'Results');
cluster_labels_raw = cluster_table.Cluster_Label;
cluster_num = zeros(31, 1);
for i = 1:31
    if contains(cluster_labels_raw{i}, 'Cluster 1')
        cluster_num(i) = 1;
    elseif contains(cluster_labels_raw{i}, 'Cluster 2')
        cluster_num(i) = 2;
    end
end
idx_c1 = find(cluster_num == 1); % ��1
idx_c2 = find(cluster_num == 2); % ��2

% ��ȡ��Ϊ����
active_data = xlsread(filename_data, 'batch1', 'B34:T64');
timeout_data = xlsread(filename_data, 'batch1', 'B66:T96');
consumption_data = xlsread(filename_data, 'batch1', 'B162:T192');

n_mice = 31;
days_sa = 1:14;
days_punish = 15:19;

%% 2. ���� 4 ������ָ��
% ָ�� 1: Press Accuracy during SA
total_active_sa = sum(active_data(:, days_sa), 2);
total_timeout_sa = sum(timeout_data(:, days_sa), 2);
accuracy_sa = total_active_sa ./ (total_active_sa + total_timeout_sa); 

% ָ�� 2: Total food earn during punishment
total_food_punish = sum(active_data(:, days_punish), 2); 

% ָ�� 3: Food utilization during SA
total_consumption_sa = sum(consumption_data(:, days_sa), 2);
food_util_sa = total_consumption_sa ./ total_active_sa;
food_util_sa(isinf(food_util_sa) | isnan(food_util_sa)) = 0; 

% ָ�� 4: Suppression Index (Day12-14 vs Day15-17)
baseline_active = mean(active_data(:, 12:14), 2);
punish_early_active = mean(active_data(:, 15:17), 2);
suppression_index = ((baseline_active - punish_early_active) ./ baseline_active) * 100;
suppression_index(isinf(suppression_index) | isnan(suppression_index)) = 0; 

metrics = [accuracy_sa, total_food_punish, food_util_sa, suppression_index];
metric_titles = {'A: SA Press Accuracy (Take/Seek)', ...
                 'B: Punishment Total Food Earn (D15-19)', ...
                 'C: SA Food Utilization (Consumption/Active)', ...
                 'D: Suppression Index (D12-14 vs D15-17)'};
y_labels = {'Ratio (Active / [Active + Timeout])', ...
            'Total Food Earn (Counts)', ...
            'Food Utilization (Consumption / Press)', ...
            'Suppression Index (%)'};

%% 3. ���� 2x2 ���ͼ
figure('Name', 'Main Figure: Behavioral Phenotypes', 'Color', 'w', 'Position', [100, 100, 1000, 800]);
colors = [0.2 0.4 0.8; 0.9 0.4 0.2]; % ��1��ɫ����2��ɫ

for f = 1:4
    subplot(2, 2, f);
    
    data_c1 = metrics(idx_c1, f);
    data_c2 = metrics(idx_c2, f);
    
    % --- ͳ�Ƽ��� ---
    [~, p, ~, stats] = ttest2(data_c1, data_c2);
    n1 = length(data_c1); n2 = length(data_c2);
    pooled_std = sqrt(((n1-1)*var(data_c1) + (n2-1)*var(data_c2)) / (n1+n2-2));
    cohens_d = (mean(data_c1) - mean(data_c2)) / pooled_std;
    
    % --- ����״ͼ ---
    bar_data = [mean(data_c1), mean(data_c2)];
    sem_data = [std(data_c1)/sqrt(n1), std(data_c2)/sqrt(n2)];
    b = bar(bar_data, 'FaceColor', 'flat', 'EdgeColor', 'k', 'LineWidth', 1.2, 'BarWidth', 0.5);
    b.CData(1,:) = colors(1,:); b.CData(2,:) = colors(2,:);
    hold on;
    
    % --- ������� ---
    errorbar([1, 2], bar_data, sem_data, 'k', 'LineStyle', 'none', 'LineWidth', 1.5, 'CapSize', 8);
    
    % --- ��ɢ��ͼ (�Ӷ���) ---
    jitter = 0.1 * (rand(length(data_c1), 1) - 0.5);
    scatter(1 + jitter, data_c1, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.6);
    jitter = 0.1 * (rand(length(data_c2), 1) - 0.5);
    scatter(2 + jitter, data_c2, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.6);
    
    % --- ����Ҫ���ϸ�̶� Y �᷶Χ�����ñ��� ---
    if f == 1 || f == 3
        % A �� C (Ratio) �̶��� 0-1
        ylim([0, 1]); 
        line_y = 0.92; % ���߷��� 92% ��
    else
        % B �� D �̶��� 0-100
        ylim([0, 100]); 
        line_y = 92;   % ���߷��� 92 ��
    end
    
    if p < 0.001, sig_str = '***';
    elseif p < 0.01, sig_str = '**';
    elseif p < 0.05, sig_str = '*';
    else, sig_str = 'ns'; end
    
    % �������Ժ��ߺ��Ǻ�
    plot([1, 2], [line_y, line_y], 'k-', 'LineWidth', 1.2);
    text(1.5, line_y + 2, sig_str, ... % ������΢����
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontSize', 12, 'FontWeight', 'bold');
    
    % ����������
    set(gca, 'XTick', [1 2], 'XTickLabel', {'Cluster 1', 'Cluster 2'}, 'FontSize', 10, 'LineWidth', 1);
    ylabel(y_labels{f}, 'FontSize', 10, 'FontWeight', 'bold');
    title(sprintf('%s\n(p = %.4f, d = %.2f)', metric_titles{f}, p, cohens_d), 'FontSize', 11);
    xlim([0.4 2.6]);
    box off;
end

% ������ͼ���
sgtitle('Behavioral Differences Between Two Clusters', 'FontSize', 14, 'FontWeight', 'bold');

% ����ͼƬ
saveas(gcf, 'Combined_4Panel_Behavioral_Figure.png');
print(gcf, 'Combined_4Panel_Behavioral_Figure.pdf', '-dpdf', '-bestfit');
disp('���ͼ�ѱ�������ǰ�ļ��� (Combined_4Panel_Behavioral_Figure.png/pdf)��');