%% ============================================================
%% �������ָ�� vs ʳ����ط������� figure 1��3��
%%   (A) ƽ������ Day1-14      vs ��ȡʳ Day1-14
%%   (B) ������ Day14-Day1      vs ��ȡʳ Day1-14
%%   (C) ƽ������ Day15-19     vs ��ȡʳ Day15-19
%%   ÿ�ž������� + Cluster 1/2 �������
%%   x ��ͳһΪ�����̶�
%%   ���ݣ�SIA_20260803.xlsx, sheet batch1
%% ============================================================
clear; clc; close all;

%% ============================================================
%% 1. ���ؾ�����������
%% ============================================================
filename_cluster = 'Learning_Clustering_Results_4Features.xlsx';
filename_data    = 'SIA_20260803.xlsx';

if ~exist(filename_cluster, 'file'), error('�������ļ�������: %s', filename_cluster); end
if ~exist(filename_data, 'file'),    error('�����ļ�������: %s', filename_data);    end

cluster_table = readtable(filename_cluster, 'Sheet', 'Results');
cluster_labels_raw = cluster_table.Cluster_Label;
cluster_num = zeros(31, 1);
for i = 1:31
    if contains(cluster_labels_raw{i}, 'Cluster 1')
        cluster_num(i) = 1;
    elseif contains(cluster_labels_raw{i}, 'Cluster 2')
        cluster_num(i) = 2;
    end
end

body_weight_data = xlsread(filename_data, 'batch1', 'B2:T32');    % 31��19
active_data      = xlsread(filename_data, 'batch1', 'B34:T64');   % 31��19
food_remain      = xlsread(filename_data, 'batch1', 'B130:T160'); % 31��19
consumption_data = active_data - food_remain;                     % 31��19

n_mice = 31;
color_c1 = [0.20, 0.40, 0.75];
color_c2 = [0.85, 0.33, 0.30];

%% ============================================================
%% 2. ����ָ��
%% ============================================================
mean_BW_train  = mean(body_weight_data(:, 1:14), 2);
delta_BW_train = body_weight_data(:, 14) - body_weight_data(:, 1);
total_food     = sum(consumption_data(:, 1:14), 2);

mean_BW_punish    = mean(body_weight_data(:, 15:19), 2);
total_food_punish = sum(consumption_data(:, 15:19), 2);

fprintf('ָ��������\n\n');

%% ============================================================
%% 3. �� figure 1��3����������ָ�� vs ʳ��
%% ============================================================
fprintf('========== ��������ָ�� vs ʳ�����ͼ ==========\n\n');

fig = figure('Name', 'BW metrics vs Food', ...
    'Position', [50, 80, 1950, 650], 'Color', 'w');
tl = tiledlayout(fig, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

%% ---------- ��� (A): ƽ������ vs ��ȡʳ ----------
nexttile; hold on;
x = mean_BW_train; y = total_food;
valid = ~isnan(x) & ~isnan(y);
x = x(valid); y = y(valid); cl = cluster_num(valid);
n_valid = sum(valid); idx1 = cl == 1; idx2 = cl == 2;

h1 = scatter(x(idx1), y(idx1), 80, color_c1, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);
h2 = scatter(x(idx2), y(idx2), 80, color_c2, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);

X = [ones(n_valid,1), x];
[b, ~, r_res, ~, ~] = regress(y, X);
xf = linspace(min(x), max(x), 100);
h3 = plot(xf, b(1)+b(2)*xf, 'k-', 'LineWidth', 2.2);

xm = mean(x); SSx = sum((x-xm).^2);
rs = sqrt(sum(r_res.^2)/(n_valid-2));
se = rs * sqrt(1/n_valid + (xf-xm).^2/SSx);
tc = tinv(0.975, n_valid-2);
fill([xf, fliplr(xf)], [b(1)+b(2)*xf+tc*se, fliplr(b(1)+b(2)*xf-tc*se)], ...
    [0.5 0.5 0.5], 'FaceAlpha', 0.15, 'EdgeColor', 'none', 'HandleVisibility', 'off');

if sum(idx1) >= 3 && range(x(idx1)) > 0
    bc1 = regress(y(idx1), [ones(sum(idx1),1), x(idx1)]);
    xf1 = linspace(min(x(idx1)), max(x(idx1)), 100);
    h4 = plot(xf1, bc1(1)+bc1(2)*xf1, '--', 'Color', color_c1, 'LineWidth', 1.8);
else, h4 = plot(nan, nan, '--', 'Color', color_c1, 'LineWidth', 1.8); end
if sum(idx2) >= 3 && range(x(idx2)) > 0
    bc2 = regress(y(idx2), [ones(sum(idx2),1), x(idx2)]);
    xf2 = linspace(min(x(idx2)), max(x(idx2)), 100);
    h5 = plot(xf2, bc2(1)+bc2(2)*xf2, '--', 'Color', color_c2, 'LineWidth', 1.8);
else, h5 = plot(nan, nan, '--', 'Color', color_c2, 'LineWidth', 1.8); end

[r_all, p_all] = corr(x, y, 'Type', 'Pearson');
if sum(idx1) >= 3, [r_c1, p_c1] = corr(x(idx1), y(idx1), 'Type', 'Pearson');
else, r_c1 = NaN; p_c1 = NaN; end
if sum(idx2) >= 3, [r_c2, p_c2] = corr(x(idx2), y(idx2), 'Type', 'Pearson');
else, r_c2 = NaN; p_c2 = NaN; end

fprintf('[ƽ������ vs ѵ������ȡʳ] Overall r=%.3f p=%.4f | C1 r=%.3f p=%.4f | C2 r=%.3f p=%.4f\n', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2);

xlabel('Mean Body Weight Day 1-14 (g)', 'FontSize', 10);
ylabel('Total Food Consumption Day 1-14 (g)', 'FontSize', 10);
title('(A) Mean BW vs Total Food (D1-14)', 'FontSize', 11, 'FontWeight', 'bold');
text(0.03, 0.97, sprintf('Overall r=%.3f, p=%.3f\nC1 r=%.3f, p=%.3f\nC2 r=%.3f, p=%.3f\nn=%d', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2, n_valid), ...
    'Units', 'normalized', 'VerticalAlignment', 'top', 'FontSize', 8, ...
    'BackgroundColor', [1 1 1 0.9], 'EdgeColor', [0.5 0.5 0.5]);
legend([h1 h2 h3 h4 h5], {'Cluster 1','Cluster 2','Overall fit','C1 fit','C2 fit'}, ...
    'Location', 'best', 'FontSize', 7.5);
grid off; box on; set(gca, 'FontSize', 9.5);

% ---- x ���޶�Ϊ���� ----
xlim([floor(min(x)), ceil(max(x))]);
xticks(floor(min(x)):ceil(max(x)));

%% ---------- ��� (B): ������ vs ��ȡʳ ----------
nexttile; hold on;
x = delta_BW_train; y = total_food;
valid = ~isnan(x) & ~isnan(y);
x = x(valid); y = y(valid); cl = cluster_num(valid);
n_valid = sum(valid); idx1 = cl == 1; idx2 = cl == 2;

h1 = scatter(x(idx1), y(idx1), 80, color_c1, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);
h2 = scatter(x(idx2), y(idx2), 80, color_c2, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);

X = [ones(n_valid,1), x];
[b, ~, r_res, ~, ~] = regress(y, X);
xf = linspace(min(x), max(x), 100);
h3 = plot(xf, b(1)+b(2)*xf, 'k-', 'LineWidth', 2.2);

xm = mean(x); SSx = sum((x-xm).^2);
rs = sqrt(sum(r_res.^2)/(n_valid-2));
se = rs * sqrt(1/n_valid + (xf-xm).^2/SSx);
tc = tinv(0.975, n_valid-2);
fill([xf, fliplr(xf)], [b(1)+b(2)*xf+tc*se, fliplr(b(1)+b(2)*xf-tc*se)], ...
    [0.5 0.5 0.5], 'FaceAlpha', 0.15, 'EdgeColor', 'none', 'HandleVisibility', 'off');

if sum(idx1) >= 3 && range(x(idx1)) > 0
    bc1 = regress(y(idx1), [ones(sum(idx1),1), x(idx1)]);
    xf1 = linspace(min(x(idx1)), max(x(idx1)), 100);
    h4 = plot(xf1, bc1(1)+bc1(2)*xf1, '--', 'Color', color_c1, 'LineWidth', 1.8);
else, h4 = plot(nan, nan, '--', 'Color', color_c1, 'LineWidth', 1.8); end
if sum(idx2) >= 3 && range(x(idx2)) > 0
    bc2 = regress(y(idx2), [ones(sum(idx2),1), x(idx2)]);
    xf2 = linspace(min(x(idx2)), max(x(idx2)), 100);
    h5 = plot(xf2, bc2(1)+bc2(2)*xf2, '--', 'Color', color_c2, 'LineWidth', 1.8);
else, h5 = plot(nan, nan, '--', 'Color', color_c2, 'LineWidth', 1.8); end

[r_all, p_all] = corr(x, y, 'Type', 'Pearson');
if sum(idx1) >= 3, [r_c1, p_c1] = corr(x(idx1), y(idx1), 'Type', 'Pearson');
else, r_c1 = NaN; p_c1 = NaN; end
if sum(idx2) >= 3, [r_c2, p_c2] = corr(x(idx2), y(idx2), 'Type', 'Pearson');
else, r_c2 = NaN; p_c2 = NaN; end

fprintf('[������ vs ѵ������ȡʳ] Overall r=%.3f p=%.4f | C1 r=%.3f p=%.4f | C2 r=%.3f p=%.4f\n', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2);

xlabel('\DeltaBody Weight Day14 - Day1 (g)', 'FontSize', 10);
ylabel('Total Food Consumption Day 1-14 (g)', 'FontSize', 10);
title('(B) \DeltaBW vs Total Food (D1-14)', 'FontSize', 11, 'FontWeight', 'bold');
text(0.03, 0.97, sprintf('Overall r=%.3f, p=%.3f\nC1 r=%.3f, p=%.3f\nC2 r=%.3f, p=%.3f\nn=%d', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2, n_valid), ...
    'Units', 'normalized', 'VerticalAlignment', 'top', 'FontSize', 8, ...
    'BackgroundColor', [1 1 1 0.9], 'EdgeColor', [0.5 0.5 0.5]);
legend([h1 h2 h3 h4 h5], {'Cluster 1','Cluster 2','Overall fit','C1 fit','C2 fit'}, ...
    'Location', 'best', 'FontSize', 7.5);
grid off; box on; set(gca, 'FontSize', 9.5);

% ---- x ���޶�Ϊ���� ----
xlim([floor(min(x)), ceil(max(x))]);
xticks(floor(min(x)):ceil(max(x)));

%% ---------- ��� (C): �ͷ���ƽ������ vs �ͷ�����ȡʳ ----------
nexttile; hold on;
x = mean_BW_punish; y = total_food_punish;
valid = ~isnan(x) & ~isnan(y);
x = x(valid); y = y(valid); cl = cluster_num(valid);
n_valid = sum(valid); idx1 = cl == 1; idx2 = cl == 2;

h1 = scatter(x(idx1), y(idx1), 80, color_c1, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);
h2 = scatter(x(idx2), y(idx2), 80, color_c2, 'filled', ...
    'MarkerEdgeColor', 'k', 'LineWidth', 0.8);

X = [ones(n_valid,1), x];
[b, ~, r_res, ~, ~] = regress(y, X);
xf = linspace(min(x), max(x), 100);
h3 = plot(xf, b(1)+b(2)*xf, 'k-', 'LineWidth', 2.2);

xm = mean(x); SSx = sum((x-xm).^2);
rs = sqrt(sum(r_res.^2)/(n_valid-2));
se = rs * sqrt(1/n_valid + (xf-xm).^2/SSx);
tc = tinv(0.975, n_valid-2);
fill([xf, fliplr(xf)], [b(1)+b(2)*xf+tc*se, fliplr(b(1)+b(2)*xf-tc*se)], ...
    [0.5 0.5 0.5], 'FaceAlpha', 0.15, 'EdgeColor', 'none', 'HandleVisibility', 'off');

if sum(idx1) >= 3 && range(x(idx1)) > 0
    bc1 = regress(y(idx1), [ones(sum(idx1),1), x(idx1)]);
    xf1 = linspace(min(x(idx1)), max(x(idx1)), 100);
    h4 = plot(xf1, bc1(1)+bc1(2)*xf1, '--', 'Color', color_c1, 'LineWidth', 1.8);
else, h4 = plot(nan, nan, '--', 'Color', color_c1, 'LineWidth', 1.8); end
if sum(idx2) >= 3 && range(x(idx2)) > 0
    bc2 = regress(y(idx2), [ones(sum(idx2),1), x(idx2)]);
    xf2 = linspace(min(x(idx2)), max(x(idx2)), 100);
    h5 = plot(xf2, bc2(1)+bc2(2)*xf2, '--', 'Color', color_c2, 'LineWidth', 1.8);
else, h5 = plot(nan, nan, '--', 'Color', color_c2, 'LineWidth', 1.8); end

[r_all, p_all] = corr(x, y, 'Type', 'Pearson');
if sum(idx1) >= 3, [r_c1, p_c1] = corr(x(idx1), y(idx1), 'Type', 'Pearson');
else, r_c1 = NaN; p_c1 = NaN; end
if sum(idx2) >= 3, [r_c2, p_c2] = corr(x(idx2), y(idx2), 'Type', 'Pearson');
else, r_c2 = NaN; p_c2 = NaN; end

fprintf('[�ͷ������� vs �ͷ�����ȡʳ] Overall r=%.3f p=%.4f | C1 r=%.3f p=%.4f | C2 r=%.3f p=%.4f\n', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2);

xlabel('Mean Body Weight Day 15-19 (g)', 'FontSize', 10);
ylabel('Total Food Consumption Day 15-19 (g)', 'FontSize', 10);
title('(C) BW vs Total Food (D15-19)', 'FontSize', 11, 'FontWeight', 'bold');
text(0.03, 0.97, sprintf('Overall r=%.3f, p=%.3f\nC1 r=%.3f, p=%.3f\nC2 r=%.3f, p=%.3f\nn=%d', ...
    r_all, p_all, r_c1, p_c1, r_c2, p_c2, n_valid), ...
    'Units', 'normalized', 'VerticalAlignment', 'top', 'FontSize', 8, ...
    'BackgroundColor', [1 1 1 0.9], 'EdgeColor', [0.5 0.5 0.5]);
legend([h1 h2 h3 h4 h5], {'Cluster 1','Cluster 2','Overall fit','C1 fit','C2 fit'}, ...
    'Location', 'best', 'FontSize', 7.5);
grid off; box on; set(gca, 'FontSize', 9.5);

% ---- x ���޶�Ϊ���� ----
xlim([floor(min(x)), ceil(max(x))]);
xticks(floor(min(x)):ceil(max(x)));

%% ---------- �ܱ��� + ���� ----------
title(tl, 'Body Weight Metrics vs Food Consumption (Training and Punishment)', ...
    'FontSize', 13, 'FontWeight', 'bold');

print(fig, 'Fig_BW_Metrics_vs_Food.png', '-dpng', '-r300');
print(fig, 'Fig_BW_Metrics_vs_Food.pdf', '-dpdf', '-bestfit');
fprintf('ͼ�ѱ��棺Fig_BW_Metrics_vs_Food.png / .pdf\n');

fprintf('============================================\n');
fprintf('������ɣ�\n');
fprintf('============================================\n');