%% ��ջ���
clear; clc; close all;

%% ��ȡ����
filename1 = 'SIA_20260803.xlsx';
filename2 = 'Learning_Clustering_Results_4Features.xlsx';

% ��Ϊ����
weight_data      = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B2:T32');
active_data      = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B34:T64');
timeout_data     = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B66:T96');
inactive_data    = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B98:T128');
foodremain_data  = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B130:T160');
foodconsume_data = readmatrix(filename1, 'Sheet', 'batch1', 'Range', 'B162:T192');

% ������
cluster_data  = readtable(filename2, 'Sheet', 'Results');
mouse_id      = cluster_data.Mouse;
cluster_label = cluster_data.Cluster_Label;

cluster_num = zeros(31,1);
for i = 1:31
    if contains(cluster_label{i}, 'Cluster 1')
        cluster_num(i) = 1;
    elseif contains(cluster_label{i}, 'Cluster 2')
        cluster_num(i) = 2;
    end
end

cluster1_idx = find(cluster_num == 1);   % Low Perf
cluster2_idx = find(cluster_num == 2);   % High Perf

%% ��������
active_c1   = active_data(cluster1_idx, :);
active_c2   = active_data(cluster2_idx, :);
inactive_c1 = inactive_data(cluster1_idx, :);
inactive_c2 = inactive_data(cluster2_idx, :);
timeout_c1  = timeout_data(cluster1_idx, :);
timeout_c2  = timeout_data(cluster2_idx, :);
food_c1     = foodconsume_data(cluster1_idx, :);
food_c2     = foodconsume_data(cluster2_idx, :);
weight_c1   = weight_data(cluster1_idx, :);
weight_c2   = weight_data(cluster2_idx, :);
remain_c1   = foodremain_data(cluster1_idx, :);
remain_c2   = foodremain_data(cluster2_idx, :);

%% ��ɫ���壨������High=�죬Low=����
color_low  = [0.2 0.2 0.8];   % Cluster 1 (Low Perf) -> ��
color_high = [0.8 0.2 0.2];   % Cluster 2 (High Perf) -> ��

%% ��ֵ��SEM ���� ѹ��
active_mean_c1   = mean(active_c1, 1);
active_mean_c2   = mean(active_c2, 1);
active_sem_c1    = std(active_c1, 0, 1) / sqrt(size(active_c1,1));
active_sem_c2    = std(active_c2, 0, 1) / sqrt(size(active_c2,1));

inactive_mean_c1 = mean(inactive_c1, 1);
inactive_mean_c2 = mean(inactive_c2, 1);
inactive_sem_c1  = std(inactive_c1, 0, 1) / sqrt(size(inactive_c1,1));
inactive_sem_c2  = std(inactive_c2, 0, 1) / sqrt(size(inactive_c2,1));

timeout_mean_c1  = mean(timeout_c1, 1);
timeout_mean_c2  = mean(timeout_c2, 1);
timeout_sem_c1   = std(timeout_c1, 0, 1) / sqrt(size(timeout_c1,1));
timeout_sem_c2   = std(timeout_c2, 0, 1) / sqrt(size(timeout_c2,1));

food_mean_c1     = mean(food_c1, 1);
food_mean_c2     = mean(food_c2, 1);
food_sem_c1      = std(food_c1, 0, 1) / sqrt(size(food_c1,1));
food_sem_c2      = std(food_c2, 0, 1) / sqrt(size(food_c2,1));

remain_mean_c1   = mean(remain_c1, 1, 'omitnan');
remain_mean_c2   = mean(remain_c2, 1, 'omitnan');
remain_sem_c1    = std(remain_c1, 0, 1, 'omitnan') ./ sqrt(size(remain_c1,1));
remain_sem_c2    = std(remain_c2, 0, 1, 'omitnan') ./ sqrt(size(remain_c2,1));

% �����ر仯��
delta_weight_c1 = [zeros(size(weight_c1,1),1), diff(weight_c1, 1, 2)];
delta_weight_c2 = [zeros(size(weight_c2,1),1), diff(weight_c2, 1, 2)];
dw_mean_c1 = mean(delta_weight_c1, 1, 'omitnan');
dw_mean_c2 = mean(delta_weight_c2, 1, 'omitnan');
dw_sem_c1  = std(delta_weight_c1, 0, 1, 'omitnan') ./ sqrt(size(delta_weight_c1,1));
dw_sem_c2  = std(delta_weight_c2, 0, 1, 'omitnan') ./ sqrt(size(delta_weight_c2,1));

%% ���ָ��
disc_c1 = zeros(size(active_c1));
disc_c2 = zeros(size(active_c2));
for i = 1:size(active_c1,1)
    for j = 1:size(active_c1,2)
        if (active_c1(i,j) + inactive_c1(i,j)) > 0
            disc_c1(i,j) = active_c1(i,j) / (active_c1(i,j) + inactive_c1(i,j));
        else
            disc_c1(i,j) = NaN;
        end
    end
end
for i = 1:size(active_c2,1)
    for j = 1:size(active_c2,2)
        if (active_c2(i,j) + inactive_c2(i,j)) > 0
            disc_c2(i,j) = active_c2(i,j) / (active_c2(i,j) + inactive_c2(i,j));
        else
            disc_c2(i,j) = NaN;
        end
    end
end
disc_mean_c1 = mean(disc_c1, 1, 'omitnan');
disc_mean_c2 = mean(disc_c2, 1, 'omitnan');
disc_sem_c1  = std(disc_c1, 0, 1, 'omitnan') / sqrt(size(disc_c1,1));
disc_sem_c2  = std(disc_c2, 0, 1, 'omitnan') / sqrt(size(disc_c2,1));

%% ѧϰб��
days = 1:19;
slope_c1 = zeros(size(active_c1,1), 2);
slope_c2 = zeros(size(active_c2,1), 2);
for i = 1:size(active_c1,1)
    p = polyfit(1:7,   active_c1(i, 1:7),   1);  slope_c1(i,1) = p(1);
    p = polyfit(13:19, active_c1(i, 13:19), 1);  slope_c1(i,2) = p(1);
end
for i = 1:size(active_c2,1)
    p = polyfit(1:7,   active_c2(i, 1:7),   1);  slope_c2(i,1) = p(1);
    p = polyfit(13:19, active_c2(i, 13:19), 1);  slope_c2(i,2) = p(1);
end

%% ʳ������Ч��
fu_c1 = zeros(size(active_c1,1), 1);
fu_c2 = zeros(size(active_c2,1), 1);
for i = 1:size(active_c1,1)
    total_food = sum(food_c1(i, :), 'omitnan');
    weight_change = weight_c1(i, end) - weight_c1(i, 1);
    if weight_change > 0, fu_c1(i) = total_food / weight_change; else, fu_c1(i) = NaN; end
end
for i = 1:size(active_c2,1)
    total_food = sum(food_c2(i, :), 'omitnan');
    weight_change = weight_c2(i, end) - weight_c2(i, 1);
    if weight_change > 0, fu_c2(i) = total_food / weight_change; else, fu_c2(i) = NaN; end
end

%% ================== ��ͼ��3��3 ���� ==================
figure('Position', [50, 50, 1600, 1000]);
x = 1:19;

% ---------- ��һ�У�����ѹ����� ----------
% ��ͼ1: Active lever press
subplot(3, 3, 1); hold on;
h1 = shadedErrorBar(x, active_mean_c1, active_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, active_mean_c2, active_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Active Lever Press'); title('Active Lever Press');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
ylim([0 50]); yticks(0:10:50);

% ��ͼ2: Inactive lever press
subplot(3, 3, 2); hold on;
h1 = shadedErrorBar(x, inactive_mean_c1, inactive_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, inactive_mean_c2, inactive_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Inactive Lever Press'); title('Inactive Lever Press');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
ylim([0 50]); yticks(0:10:50);

% ��ͼ3: Timeout lever press
subplot(3, 3, 3); hold on;
h1 = shadedErrorBar(x, timeout_mean_c1, timeout_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, timeout_mean_c2, timeout_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Timeout Lever Press'); title('Timeout Lever Press');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
ylim([0 50]); yticks(0:10:50);

% ---------- �ڶ��У�����ָ�� ----------
% ��ͼ4: Learning Slope
subplot(3, 3, 4); hold on;
slope_data = [slope_c1(:,1); slope_c2(:,1); slope_c1(:,2); slope_c2(:,2)];
group = [ones(size(slope_c1,1),1); 2*ones(size(slope_c2,1),1); ...
         3*ones(size(slope_c1,1),1); 4*ones(size(slope_c2,1),1)];
boxplot(slope_data, group, 'Colors', [color_low; color_high; color_low; color_high], ...
    'Symbol', 'o', 'Widths', 0.6);
xticklabels({'C1-Early', 'C2-Early', 'C1-Late', 'C2-Late'});
ylabel('Learning Slope (Active Press/Day)'); title('Learning Slope');
grid off; box on; set(gca, 'FontSize', 11);
for i = 1:size(slope_c1,1)
    plot(1, slope_c1(i,1), 'o', 'Color', color_low,  'MarkerSize', 6, 'MarkerFaceColor', color_low);
    plot(3, slope_c1(i,2), 'o', 'Color', color_low,  'MarkerSize', 6, 'MarkerFaceColor', color_low);
end
for i = 1:size(slope_c2,1)
    plot(2, slope_c2(i,1), 'o', 'Color', color_high, 'MarkerSize', 6, 'MarkerFaceColor', color_high);
    plot(4, slope_c2(i,2), 'o', 'Color', color_high, 'MarkerSize', 6, 'MarkerFaceColor', color_high);
end

% ��ͼ5: Discrimination Index
subplot(3, 3, 5); hold on;
h1 = shadedErrorBar(x, disc_mean_c1, disc_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, disc_mean_c2, disc_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Discrimination Index');
title('Discrimination Index (Active/(Active+Inactive))');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; ylim([0 1]); set(gca, 'FontSize', 11);

% ��ͼ6: Food Utilization
subplot(3, 3, 6); hold on;
x_jitter1 = ones(size(fu_c1,1), 1) + 0.1 * (rand(size(fu_c1,1), 1) - 0.5);
x_jitter2 = 2 * ones(size(fu_c2,1), 1) + 0.1 * (rand(size(fu_c2,1), 1) - 0.5);
scatter(x_jitter1, fu_c1, 60, color_low,  'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
scatter(x_jitter2, fu_c2, 60, color_high, 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
mean_fu_c1 = mean(fu_c1, 'omitnan');
mean_fu_c2 = mean(fu_c2, 'omitnan');
line([0.6 1.4], [mean_fu_c1 mean_fu_c1], 'Color', color_low,  'LineWidth', 2);
line([1.6 2.4], [mean_fu_c2 mean_fu_c2], 'Color', color_high, 'LineWidth', 2);
xlim([0.5 2.5]); xticks([1 2]); xticklabels({'Cluster 1', 'Cluster 2'});
ylabel('Food Utilization (g food / g weight gain)'); title('Food Utilization');
grid off; box on; set(gca, 'FontSize', 11);

% ---------- �����У����ر仯������ʳ����ʳ��ʣ���� ----------
% ��ͼ7: Daily Weight Change
subplot(3, 3, 7); hold on;
h1 = shadedErrorBar(x, dw_mean_c1, dw_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, dw_mean_c2, dw_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Daily Weight Change (g)'); title('Daily Weight Change');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
xlim([1 19]); ylim([-2 2]); yticks(-2:1:2);

% ��ͼ8: Food Consumption
subplot(3, 3, 8); hold on;
h1 = shadedErrorBar(x, food_mean_c1, food_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, food_mean_c2, food_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Food Consumed (g)'); title('Food Consumption');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
xlim([1 19]); ylim([0 30]);

% ��ͼ9: Food Remaining
subplot(3, 3, 9); hold on;
h1 = shadedErrorBar(x, remain_mean_c1, remain_sem_c1, {'Color', color_low,  'LineWidth', 2}, 1);
h2 = shadedErrorBar(x, remain_mean_c2, remain_sem_c2, {'Color', color_high, 'LineWidth', 2}, 1);
xlabel('Day'); ylabel('Food Remaining (g)'); title('Food Remaining');
legend([h1.mainLine, h2.mainLine], {'Cluster 1 (Low Perf)', 'Cluster 2 (High Perf)'}, ...
    'Location', 'northwest');
grid off; box on; set(gca, 'FontSize', 11);
xlim([1 19]); ylim([0 30]);

%% ����
saveas(gcf, 'Behavioral_Analysis_Clusters_Combined.png');
fprintf('ͼƬ�ѱ���Ϊ: Behavioral_Analysis_Clusters_Combined.png\n');

%% ��������: shadedErrorBar
function h = shadedErrorBar(x, y, errBar, lineProps, transparent)
    if nargin < 5, transparent = 1; end
    if isempty(lineProps), lineProps = {'Color', [0 0 0]}; end

    yPlot = y; errPlot = errBar;
    nanIdx = isnan(yPlot) | isnan(errPlot);
    if any(nanIdx)
        yPlot(nanIdx)   = interp1(x(~nanIdx), yPlot(~nanIdx), x(nanIdx), 'linear', 'extrap');
        errPlot(nanIdx) = interp1(x(~nanIdx), errPlot(~nanIdx), x(nanIdx), 'linear', 'extrap');
    end

    xFill = [x, fliplr(x)];
    yFill = [yPlot + errPlot, fliplr(yPlot - errPlot)];
    fill(xFill, yFill, lineProps{2}, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
    hold on;
    h.mainLine = plot(x, yPlot, lineProps{:}, 'LineWidth', 2);
end