%% =========================================================
%% BH-FDR correction, separated into TWO families
%%   Family 1 (SA phase, days 1-14):        m = 2
%%   Family 2 (Punishment phase, days 15-19): m = 3
%% ���: FDR_two_families_results.xlsx / .csv
%% =========================================================
clear; clc;

%% 1. ������
cluster_table = readtable('Learning_Clustering_Results_4Features.xlsx', 'Sheet', 'Results');
cluster_labels_raw = cluster_table.Cluster_Label;
cluster_num = zeros(31,1);
for i = 1:31
    if contains(cluster_labels_raw{i}, 'Cluster 1')
        cluster_num(i) = 1;
    elseif contains(cluster_labels_raw{i}, 'Cluster 2')
        cluster_num(i) = 2;
    end
end
idx_c1 = find(cluster_num == 1);
idx_c2 = find(cluster_num == 2);

%% 2. ����Ϊ����
active_data      = xlsread('SIA_20260803.xlsx', 'batch1', 'B34:T64');
timeout_data     = xlsread('SIA_20260803.xlsx', 'batch1', 'B66:T96');
consumption_data = xlsread('SIA_20260803.xlsx', 'batch1', 'B162:T192');

days_sa     = 1:14;
days_punish = 15:19;

%% 3. ���� 5 ��ָ��
% --- SA �׶� ---
total_active_sa  = sum(active_data(:, days_sa), 2);
total_timeout_sa = sum(timeout_data(:, days_sa), 2);
accuracy_sa = total_active_sa ./ (total_active_sa + total_timeout_sa);

total_consumption_sa = sum(consumption_data(:, days_sa), 2);
food_util_sa = total_consumption_sa ./ total_active_sa;
food_util_sa(isinf(food_util_sa) | isnan(food_util_sa)) = 0;

% --- Punishment �׶� ---
total_food_punish = sum(active_data(:, days_punish), 2);

baseline_active     = mean(active_data(:, 12:14), 2);
punish_early_active = mean(active_data(:, 15:17), 2);
suppression_index = ((baseline_active - punish_early_active) ./ baseline_active) * 100;
suppression_index(isinf(suppression_index) | isnan(suppression_index)) = 0;

active_punish      = sum(active_data(:, days_punish), 2);
consumption_punish = sum(consumption_data(:, days_punish), 2);
util_punish = consumption_punish ./ active_punish;
util_punish(isinf(util_punish) | isnan(util_punish)) = 0;

%% 4. �������� family
% Family 1: SA phase  -> accuracy_sa, food_util_sa
% Family 2: Punishment -> total_food_punish, suppression_index, util_punish
family_id = [1; 1; 2; 2; 2];   % ������ metrics ��˳���Ӧ

metrics = [accuracy_sa, food_util_sa, ...
           total_food_punish, suppression_index, util_punish];

metric_names = {'SA_Press_Accuracy', ...
                'SA_Food_Utilization', ...
                'Punishment_Total_Food_Earn', ...
                'Suppression_Index', ...
                'Punishment_Food_Utilization'};
family_names = {'SA_phase'; 'Punishment_phase'};
n_metrics = numel(metric_names);

%% 5. ��ָ�� t-test + Cohen's d��Student, two-tailed��
p_raw  = zeros(n_metrics,1);
tstat  = zeros(n_metrics,1);
cohend = zeros(n_metrics,1);
mean_c1 = zeros(n_metrics,1); sem_c1 = zeros(n_metrics,1);
mean_c2 = zeros(n_metrics,1); sem_c2 = zeros(n_metrics,1);

for f = 1:n_metrics
    d1 = metrics(idx_c1, f);  d2 = metrics(idx_c2, f);
    n1 = numel(d1); n2 = numel(d2);
    [~, p, ~, st] = ttest2(d1, d2);
    p_raw(f) = p;  tstat(f) = st.tstat;
    pooled_sd = sqrt(((n1-1)*var(d1) + (n2-1)*var(d2)) / (n1+n2-2));
    cohend(f) = (mean(d1) - mean(d2)) / pooled_sd;
    mean_c1(f) = mean(d1); sem_c1(f) = std(d1)/sqrt(n1);
    mean_c2(f) = mean(d2); sem_c2(f) = std(d2)/sqrt(n2);
end

%% 6. �� family �� BH-FDR
p_adj = nan(n_metrics,1);
p_adj_sorted_global = nan(n_metrics,1);
family_size = zeros(n_metrics,1);

for fam = 1:2
    idx_fam = find(family_id == fam);
    m = numel(idx_fam);
    family_size(idx_fam) = m;
    p_fam = p_raw(idx_fam);

    % BH: ���� -> �� m/i -> �ۻ���С -> �� 1
    [p_sorted, sort_idx] = sort(p_fam);
    adj_sorted = p_sorted .* m ./ (1:m)';
    adj_sorted = cummin(adj_sorted(end:-1:1));
    adj_sorted = adj_sorted(end:-1:1);
    adj_sorted = min(adj_sorted, 1);

    p_adj_fam = zeros(m,1);
    p_adj_fam(sort_idx) = adj_sorted;
    p_adj(idx_fam) = p_adj_fam;
end

%% 7. ���ɱ���
sig_raw = cell(n_metrics,1); sig_adj = cell(n_metrics,1);
for f = 1:n_metrics
    sig_raw{f} = star_label(p_raw(f));
    sig_adj{f} = star_label(p_adj(f));
end
fam_label = cell(n_metrics,1);
for f = 1:n_metrics
    fam_label{f} = family_names{family_id(f)};
end

T = table(metric_names', fam_label, family_size, ...
          mean_c1, sem_c1, mean_c2, sem_c2, ...
          tstat, p_raw, p_adj, cohend, sig_raw, sig_adj, ...
    'VariableNames', {'Metric','Family','Family_m', ...
                      'Mean_C1','SEM_C1','Mean_C2','SEM_C2', ...
                      't','p_raw','p_FDR','Cohens_d','Sig_raw','Sig_FDR'});

disp('========== BH-FDR (Two Families) ==========');
disp('Family 1: SA phase (m=2)');
disp(T(strcmp(T.Family, 'SA_phase'), :));
disp('Family 2: Punishment phase (m=3)');
disp(T(strcmp(T.Family, 'Punishment_phase'), :));

writetable(T, 'FDR_two_families_results.xlsx', 'Sheet', 'FDR_two_families');
writetable(T, 'FDR_two_families_results.csv');

%% 8. ����̨ժҪ
fprintf('\n--- У��ǰ�������ԣ��� family �ֱ�У����---\n');
for f = 1:n_metrics
    fprintf('[%s, m=%d] %-30s p_raw=%.4f (%s) -> p_FDR=%.4f (%s)\n', ...
        fam_label{f}, family_size(f), metric_names{f}, ...
        p_raw(f), sig_raw{f}, p_adj(f), sig_adj{f});
end

%% ��������
function s = star_label(p)
    if isnan(p),      s = 'NA';
    elseif p < 0.001, s = '***';
    elseif p < 0.01,  s = '**';
    elseif p < 0.05,  s = '*';
    else,             s = 'ns';
    end
end