"""Convert statistical P only; preserve posterior direction labels P."""
import re,json
from pathlib import Path
import matplotlib as mpl
from matplotlib.text import Text
from matplotlib.collections import PathCollection
from matplotlib.markers import MarkerStyle
import numpy as np
mpl.rcParams.update({'mathtext.fontset':'custom','mathtext.rm':'Arial',
    'mathtext.it':'Arial:italic','mathtext.bf':'Arial:bold','mathtext.sf':'Arial',
    'mathtext.fallback':None})
def apply_p_style(fig):
    for t in fig.findobj(match=lambda o:isinstance(o,Text)):
        s=t.get_text()
        if s=='P' and t.axes is not None and t.axes.axison:
            t.set_text(r'$\mathit{p}$')
        else:
            t.set_text(re.sub(r'\bP\b(?=\s*(?:[=<>≥≤]|values))',lambda _:r'$\mathit{p}$',s))
def record_axes(fig,name,out):
    rows=[]
    for a in fig.axes:
        if a.axison:
            circle=MarkerStyle('o').get_path().transformed(MarkerStyle('o').get_transform())
            scatter=[]
            for c in a.collections:
                if isinstance(c,PathCollection):
                    paths=c.get_paths()
                    is_circle=all(p.vertices.shape==circle.vertices.shape and np.allclose(p.vertices,circle.vertices) for p in paths)
                    scatter.append(dict(n=len(c.get_offsets()),circle=is_circle,edgecolors=c.get_edgecolors().tolist(),facecolors=c.get_facecolors().tolist(),linewidths=c.get_linewidths().tolist()))
            rows.append(dict(title=a.get_title(),xlabel=a.get_xlabel(),ylabel=a.get_ylabel(),
                xlim=list(a.get_xlim()),ylim=list(a.get_ylim()),xticks=list(a.get_xticks()),yticks=list(a.get_yticks()),
                individual_gray_lines=sum(l.get_color()=='#CCCCCC' and len(l.get_xdata())==3 for l in a.lines),scatter=scatter))
    (Path(out)/f'{name}_axes.json').write_text(json.dumps(rows,indent=2,default=float))
