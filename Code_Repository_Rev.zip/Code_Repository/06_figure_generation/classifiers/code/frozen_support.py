"""Reorganized Fig. 4/5 and Supplementary Fig. 5 from frozen inputs only.
No classifiers are instantiated, trained or tuned. No inferential estimates are recomputed.
Only display summaries (raw means/SEM) and checks of saved predictions are calculated.
"""
from style import *
from anatomy import brain,POS,LAB,COL,CON
from matplotlib.patches import Rectangle
import hashlib,sys

CORE=['ACC–NAc','ACC–DMS','ACC–DLS','PrL–NAc','PrL–DMS','PrL–DLS']
TRI=['DLS-M1','M1-AI','DLS-AI']
z=np.load(HERE/'inputs/frozen_data13.npz',allow_pickle=True)
base=read('baseline_prefrontal_striatal_6').set_index('connection').loc[CORE].reset_index()
perf=read('six_fixed_classifier_performance')
pred=read('six_fixed_classifier_records')
oldperf=read('prior_Prediction_performance')
baseline_margin=read('prior_Fig5e');triad_margin=read('prior_Fig5f')
np.testing.assert_array_equal(baseline_margin.animal,triad_margin.animal)
np.testing.assert_array_equal(baseline_margin.label,[0]*7+[1]*3)
DISPLAY={a:i+1 for i,a in enumerate(baseline_margin.animal)}
checks=[]
def check(name,ok):
 assert bool(ok),name
 checks.append(dict(check=name,passed=True))
def edge_index(edge):
 a,b=edge.replace('–','-').split('-')
 return next(i for i,e in enumerate(z['edge_names']) if set(e.split('-'))=={a,b})
def baseline_data():
 rows=[]
 for e in ['ACC–DMS','ACC–DLS']:
  vals=z['B'][:,edge_index(e)]
  for a,b,g,v in zip(z['animals'],z['batch'],z['labels'],vals):
   rows.append(dict(connection=e,animal=a,batch=b,group=g,FC=v))
 return pd.DataFrame(rows)
def verify():
 for m in json.loads((HERE/'inputs/manifest.json').read_text()):
  check('Input hash: '+m['file'],hashlib.sha256((HERE/'inputs'/m['file']).read_bytes()).hexdigest()==m['sha256'])
 check('Prior audit verified frozen arrays',json.loads((HERE/'inputs/verification_prior.json').read_text())['frozen_arrays_unchanged'])
 for records,metricrows,keycol in [(pred,perf,'connection'),(read('prior_Prediction_records_all_82'),oldperf,'model')]:
  for (name,scheme),t in records.groupby([keycol,'scheme']):
   r=metricrows[(metricrows[keycol]==name)&(metricrows.scheme==scheme)].iloc[0]
   y=t.label.to_numpy();h=t.prediction.to_numpy();score=t.score.to_numpy()
   ba=((h[y==0]==0).mean()+(h[y==1]==1).mean())/2
   hi=score[y==1,None];lo=score[y==0][None,:];auc=np.mean((hi>lo)+.5*(hi==lo))
   check(f'{name}/{scheme} saved metrics',np.allclose([ba,auc,(h==y).sum()],[r.balanced_accuracy,r.auc,r.correct],atol=1e-12))
 for tag,t in [('ACC–DMS',baseline_margin),('Triad',triad_margin)]:
  check(tag+' saved margin equals score minus threshold',np.allclose(t.decision_margin,t.score-t.threshold,atol=1e-12))
  check(tag+' predictions reproduce saved threshold',np.array_equal((t.decision_margin>=0).astype(int),t.prediction))
 check('Same test-animal order',baseline_margin.animal.tolist()==triad_margin.animal.tolist())
 p=pred[(pred.connection=='ACC–DMS')&(pred.scheme=='B2toB1')].set_index('animal').loc[baseline_margin.animal]
 check('ACC–DMS records agree between frozen exports',np.allclose(p.score,baseline_margin.score) and np.array_equal(p.prediction,baseline_margin.prediction))
 check('ACC–DMS error at anonymous index 1',np.flatnonzero(baseline_margin.label!=baseline_margin.prediction).tolist()==[0])
 check('Triad errors at anonymous indices 3, 5, 7',np.flatnonzero(triad_margin.label!=triad_margin.prediction).tolist()==[2,4,6])
 t=read('prior_Fig4b');ix=[edge_index(e) for e in TRI]
 for phase in 'BLS':
  v=t[t.phase==phase].set_index('animal').loc[z['animals'],'mean_FC']
  check('Triad '+phase+' equals all-three-edge mean',np.allclose(v,z[phase][:,ix].mean(1),atol=1e-12))
 d=read('prior_Fig4c').set_index('animal').loc[z['animals'],'delta_FC']
 check('Training change equals saved after minus before',np.allclose(d,(z['L'][:,ix]-z['B'][:,ix]).mean(1),atol=1e-12))
 for e,t in baseline_data().groupby('connection'):
  row=base[base.connection==e].iloc[0]
  check(e+' raw means agree with saved estimates',np.allclose([t[t.group==0].FC.mean(),t[t.group==1].FC.mean()],[row.low_mean,row.high_mean]))
 source('Anonymous_test_animal_order',pd.DataFrame(dict(anonymous_index=range(1,11),animal=baseline_margin.animal,label=baseline_margin.label)))

