"""Frozen estimates and scores: no estimator fitting or threshold selection.
KDEs are descriptive displays only. Classifier metrics, labels, scores and
thresholds are read from frozen records without fitting or remapping.
"""
from style import *
import frozen_support as F
from anatomy import POS,COL,CON
from scipy.stats import gaussian_kde
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,PathPatch
from matplotlib.path import Path as MPath
from matplotlib import patheffects as pe
from matplotlib.gridspec import GridSpec
import itertools,json

CORE=F.CORE;TRI=F.TRI
BASE=F.base;PERF=F.perf
OUTSIDE_LABELS={'M1':(1.4,5.2),'DLS':(-4.0,4.7),'AI':(6.7,-2.2),
 'ACC':(1.0,5.4),'PrL':(6.3,4.6),'NAc':(1.4,-4.6),'DMS':(6.3,-1.9)}

def verify_inputs():
 F.verify()
 source('External_ROI_labels',pd.DataFrame([dict(ROI=k,anchor_AP=POS[k][0],anchor_DV=POS[k][1],label_AP=v[0],label_DV=v[1]) for k,v in OUTSIDE_LABELS.items()]))

def brain(a,nodes,edges,baseline=False):
 a.axis('off');a.set_aspect('equal');a.set_xlim(8.4,-8.2);a.set_ylim(-5.6,6.5)
 for name,fc,ec,lw,ls in [('whole','#F8F8F7','#8F9498',.65,'-'),('cerebellum','#ECEEED','#C2C5C4',.5,'--'),('isocortex','none','#D6D8D6',.4,'-'),('striatum','#ECEBEF','#C8C5D0',.45,'-'),('olfactory','none','#C8CBC8',.45,'-')]:
  for k in CON.files:
   if k.startswith(name+'_'):a.add_patch(PathPatch(MPath(CON[k],closed=True),facecolor=fc,edgecolor=ec,lw=lw,ls=ls,zorder=0))
 def draw(e,on):
  aa,bb=e.split('-');color=HIGH;lw=1.7
  if baseline:color=HIGH if e=='ACC-DMS' else LOW;lw=2.4 if e=='ACC-DMS' else 1.8
  if not on:color='#A5AAB5';lw=1.0
  p=FancyArrowPatch(POS[aa],POS[bb],connectionstyle='arc3,rad=0.14',arrowstyle='-',
       color=color,lw=lw,linestyle='-' if on else (0,(3,2)),zorder=3 if on else 1,shrinkA=0,shrinkB=0)
  if on:p.set_path_effects([pe.Stroke(linewidth=3.2,foreground='white'),pe.Normal()])
  a.add_patch(p)
 if baseline:
  for e in edges:
   if e not in ['ACC-DMS','ACC-DLS']:draw(e,False)
 for e in edges:
  if not baseline or e in ['ACC-DMS','ACC-DLS']:draw(e,True)
 for n in nodes:
  a.plot(*POS[n],marker='o',ms=4.5,mfc=COL[n],mec='#454545',mew=.6,ls='',zorder=5)
  a.annotate(n,xy=POS[n],xytext=OUTSIDE_LABELS[n],ha='center',va='center',fontsize=6.5,
   bbox=dict(boxstyle='round,pad=.18,rounding_size=.2',fc=COL[n],ec='none',alpha=.92),
   arrowprops=dict(arrowstyle='-',color='#555555',lw=.65,shrinkA=2,shrinkB=3),zorder=6)
 line,=a.plot([-4.7,-5.7],[-4.35,-4.35],color=DARK,lw=1)
 label=a.annotate('1 mm',xy=(-5.2,-4.35),xytext=(0,-4.2),textcoords='offset points',ha='center',va='top',fontsize=6.5)
 a._scale_bar=(line,label)
 # Positive anterior coordinate points left in this sagittal projection; dorsal is up.
 x,y=.12,.07;d=.055
 a.plot([x-d,x+d],[y,y],transform=a.transAxes,color=DARK,lw=.65,clip_on=False)
 a.plot([x,x],[y-d,y+d],transform=a.transAxes,color=DARK,lw=.65,clip_on=False)
 for text,xx,yy,ha,va in [('A',x-d-.018,y,'right','center'),('P',x+d+.018,y,'left','center'),
                          ('D',x,y+d+.018,'center','bottom'),('V',x,y-d-.018,'center','top')]:
  a.text(xx,yy,text,transform=a.transAxes,ha=ha,va=va,fontsize=6)

def workflow(a):
 a.axis('off')
 labs=['3-edge mean ΔFC\n(L − B)','Training-only\nΔFD regression',
       '1D nearest-centroid\n& CV threshold','Held-out\ngroup prediction']
 for j,lab in enumerate(labs):
  yy=.905-j*.27
  a.add_patch(FancyBboxPatch((.03,yy-.0775),.94,.155,boxstyle='round,pad=.008,rounding_size=.035',
       fc='#F5F7FA',ec='#CBD5E1',lw=.65,transform=a.transAxes))
  a.text(.5,yy,lab,ha='center',va='center',fontsize=6.5,transform=a.transAxes)
  if j<3:a.annotate('',xy=(.5,yy-.27+.0855),xytext=(.5,yy-.0855),xycoords='axes fraction',arrowprops=dict(arrowstyle='-|>',lw=.7,color='#64748B',shrinkA=4,shrinkB=4,mutation_scale=6))
 source('Fig4a_workflow',pd.DataFrame({'step':range(1,5),'description':labs}))

def rain(a,t,col,annotation='',compact=False):
 rng=np.random.default_rng(20261025)
 for g,c in [(0,LOW),(1,HIGH)]:
  s=t[t.group==g];v=s[col].to_numpy();jitter=.03 if compact else .05;xx=g-.14+rng.uniform(-jitter,jitter,len(s))
  yy=np.linspace(v.min(),v.max(),220);den=gaussian_kde(v)(yy);width=(.11 if compact else .18)*den/den.max()
  a.fill_betweenx(yy,g+.12,g+.12+width,color=c,alpha=.22,lw=0,zorder=1)
  a.plot(g+.12+width,yy,color=c,lw=.8,alpha=.75,zorder=2)
  for b,m in [('B1','s'),('B2','o')]:
   ix=s.batch.to_numpy()==b;a.scatter(xx[ix],v[ix],marker=m,s=20 if compact else 15,
      fc='white' if g==0 else c,ec=c,alpha=1 if g==0 else .88,lw=.7,zorder=4)
  mu=v.mean();sem=v.std(ddof=1)/np.sqrt(len(v))
  a.errorbar(g+.08,mu,yerr=sem,fmt='D',ms=4.1,mfc=c,mec='white',mew=.6,ecolor=c,lw=1.6,capsize=2.5,zorder=6)
 a.set_xlim(-.42,1.44);a.set_xticks([0,1],['Low','High'] if compact else ['Low earners','High earners'])
 headroom(a,t[col],.25 if compact else .22)
 if annotation:note(a,annotation)
 a.tick_params(axis='x',pad=3)

def forest(a,t,pc='P_wild'):
 for j,r in enumerate(t.itertuples()):
  yy=len(t)-j-1;on=getattr(r,pc)<.05;col=(HIGH if j==1 else LOW) if on else '#666666'
  a.errorbar(r.effect,yy,xerr=[[r.effect-r.CI_low],[r.CI_high-r.effect]],fmt='o',ms=4.2 if on else 3.6,
    mfc=col if on else 'white',mec=col,ecolor=col,lw=1.3 if on else .85,capsize=2,zorder=3)
  a.text(.061,yy,f'{getattr(r,pc):.4f}',va='center',fontsize=6.5)
 a.set_yticks(range(len(t)-1,-1,-1),t.connection);a.tick_params(axis='y',length=0,pad=3)
 a.set_xlim(-.32,.15);a.set_ylim(-.55,len(t)-.3);a.set_xticks([-.3,-.2,-.1,0]);zero(a,'v')
 a.text(.061,len(t)-.08,'P',fontsize=6.5,clip_on=False)
 a.set_xlabel('High − low pre-training FC\n(Fisher z, 95% CI)',labelpad=3)

def stems(a,t,annotation):
 a.set_ylim(-4.6,6.2);a.set_xlim(.35,10.65)
 a.axhspan(0,6.2,color='#FDF2F0',alpha=.55,lw=0,zorder=-3)
 a.axhspan(-4.6,0,color='#F0F5FA',alpha=.55,lw=0,zorder=-3)
 for r in t.itertuples():
  x=F.DISPLAY[r.animal];c=LOW if r.label==0 else HIGH
  a.vlines(x,0,r.decision_margin,color=c,lw=1.1,alpha=.6,zorder=1)
  a.scatter(x,r.decision_margin,s=22,marker='s',fc='white' if r.label==0 else c,ec=c,lw=.8,zorder=4)
  if r.label!=r.prediction:
   a.scatter(x,r.decision_margin,s=100,fc='none',ec='#222222',lw=1.3,zorder=3)
 zero(a);a.set_xticks(range(1,11));a.set_yticks([-4,-2,0,2,4]);a.set_ylabel('Decision margin',labelpad=3)
 a.set_xlabel('Test animal (anonymous index)',labelpad=3)
 a.text(.98,.64,'Predicted high',transform=a.transAxes,ha='right',va='top',fontstyle='italic',fontsize=6)
 a.text(.98,.035,'Predicted low',transform=a.transAxes,ha='right',va='bottom',fontstyle='italic',fontsize=6)
 a.text(.04,.95,annotation,transform=a.transAxes,va='top',ha='left',fontsize=6.3)

def boxed(a,xlim,ylim):
 for s in a.spines.values():s.set_visible(True);s.set_linewidth(.8);s.set_color(DARK)
 a.set_xlim(*xlim);a.set_ylim(*ylim);a.grid(True,color='#EDEDED',lw=.55,zorder=0)
 a.axvline(50,color='#999999',ls='--',lw=.65);a.axhline(.5,color='#999999',ls='--',lw=.65)
 a.set_xlabel('Balanced accuracy (%)',labelpad=3);a.set_ylabel('ROC AUC',labelpad=3)

def performance_bubble(a,baseline=False):
 boxed(a,(45,98),(.45,.92));a.set_xticks([50,60,70,80,90]);a.set_yticks([.5,.6,.7,.8,.9])
 t=(PERF[PERF.connection=='ACC–DMS'] if baseline else F.oldperf[F.oldperf.model.str.startswith('DLS')]).set_index('scheme')
 r1=t.loc['LOO'];r2=t.loc['B2toB1']
 if baseline:
  offsets={'PrL–DLS':(0,8),'PrL–NAc':(-5,9),'PrL–DMS':(13,-10),'ACC–NAc':(-2,9),'ACC–DLS':(11,-11)}
  ref=PERF[(PERF.scheme=='B2toB1')&(PERF.connection!='ACC–DMS')]
  for r in ref.itertuples():
   a.scatter(100*r.balanced_accuracy,r.auc,s=23,fc='#B7BDC4',ec='white',lw=.5,alpha=.65,zorder=2)
   a.annotate(r.connection,xy=(100*r.balanced_accuracy,r.auc),xytext=offsets[r.connection],textcoords='offset points',
       fontsize=6,color='#737373',ha='center',va='center',zorder=4)
 arrow=FancyArrowPatch((100*r1.balanced_accuracy,r1.auc),(100*r2.balanced_accuracy,r2.auc),
   arrowstyle='-|>',color='#8A8A8A',lw=.85,linestyle='--',connectionstyle='arc3,rad='+('.22' if baseline else '.28'),
   shrinkA=8,shrinkB=8,mutation_scale=8,zorder=1)
 a.add_patch(arrow);a._performance_arrow=arrow
 for r,c in [(r1,'#76B7A9'),(r2,'#F07857' if baseline else '#E0B882')]:
  a.scatter(100*r.balanced_accuracy,r.auc,s=185,fc=c,ec='white',lw=.7,alpha=.88,zorder=3)
 if baseline:
  a.text(.04,.96,f'Batch 2→1: BA {100*r2.balanced_accuracy:.1f}% · AUC {r2.auc:.3f}',transform=a.transAxes,ha='left',va='top',fontsize=6.5,fontweight='bold')
  a.text(.04,.82,f'LOO: BA {100*r1.balanced_accuracy:.1f}% · AUC {r1.auc:.3f}',transform=a.transAxes,ha='left',va='top',fontsize=6.5,fontweight='bold')
  source('Fig5d',t.reset_index());source('Fig5d_background',ref)
 else:
  a.text(.5,.93,f'LOO: BA {100*r1.balanced_accuracy:.1f}% · AUC {r1.auc:.3f}',transform=a.transAxes,ha='center',va='top',fontsize=6.5,fontweight='bold')
  a.text(.5,.12,f'Batch 2→1: BA {100*r2.balanced_accuracy:.1f}% · AUC {r2.auc:.3f}',transform=a.transAxes,ha='center',va='bottom',fontsize=6.5,fontweight='bold')
  source('Fig4e',t.reset_index())

def fig4():
 f=canvas(165);key(f);gs=f.add_gridspec(3,2,left=.09,right=.96,bottom=.16,top=.94,hspace=.46,wspace=.36)
 title(f,gs[0,0],'a','Three-node feature and classification')
 p=gs[0,0].get_position(f);a=tag(f.add_axes([.025,p.y0,.23,p.height]),'a');brain(a,['DLS','M1','AI'],TRI)
 a.text(.5,-.07,'Equal-weight mean of\nall 3 internal edges',transform=a.transAxes,ha='center',va='top',fontsize=6)
 b=tag(f.add_axes([.262,p.y0,.202,p.height]),'a');workflow(b)
 source('Fig4a',read('triad_food_earned_associations').assign(equal_weight=1/3))
 a=tag(f.add_subplot(gs[0,1]),'b');title(f,gs[0,1],'b','DLS–M1–AI across stages')
 t=read('prior_Fig4b');piv=t.pivot(index='animal',columns='phase',values='mean_FC').loc[:,list('BLS')]
 a.axvspan(0,1,color='#F6F3EF',zorder=-3)
 for row in piv.to_numpy():a.plot(range(3),row,color='#D0D5DD',lw=.6,zorder=1)
 for g,c,m,ls in [(0,LOW,'s','--'),(1,HIGH,'o','-')]:
  s=read('prior_Fig4b_summary');s=s[s.group==g].set_index('phase').loc[list('BLS')]
  a.errorbar(range(3),s['mean'],yerr=s.SEM,color=c,ls=ls,lw=2,marker=m,ms=4.4,
    mfc='white' if g==0 else c,mec='white',mew=.65,capsize=2,zorder=4)
  if g==0:a.plot(range(3),s['mean'],ls='',marker=m,ms=3.4,mfc='white',mec=c,mew=.7,zorder=5)
 a.set_xticks(range(3),['Before\ntraining','After\ntraining','After\npunishment']);a.set_ylabel('Mean FC (Fisher z)',labelpad=3);a.margins(x=.12)
 headroom(a,t.mean_FC,.22);pval=read('selected_network_interactions_wild').query('rois=="DLS;M1;AI"').P_wild.iloc[0]
 note(a,f'Group × stage P = {pval:.4f}')
 a.text(.5,.025,'Training phase (ΔFC)',transform=a.get_xaxis_transform(),ha='center',va='bottom',fontsize=6,color='#737373',fontstyle='normal')
 source('Fig4b',t);source('Fig4b_summary',read('prior_Fig4b_summary'))
 a=tag(f.add_subplot(gs[1,0]),'c');title(f,gs[1,0],'c','Training-related ΔFC')
 t=read('prior_Fig4c');r=read('prior_Fig4d').iloc[0]
 rain(a,t,'delta_FC',f'Adjusted diff = {r.effect:.3f}, P = {r.P:.4f}');zero(a);a.set_ylabel('Training ΔFC (Fisher z)',labelpad=3);source('Fig4c',t)
 a=tag(f.add_subplot(gs[1,1]),'d');title(f,gs[1,1],'d','Starting-state sensitivity')
 p=a.get_position();a.set_position([p.x0+.055,p.y0,p.width-.055,p.height])
 t=read('prior_Fig4d')
 for j,r in enumerate(t.itertuples()):
  c=LOW if j==0 else '#555555';yy=1-j
  a.errorbar(r.effect,yy,xerr=[[r.effect-r.CI_low],[r.CI_high-r.effect]],fmt='o' if j==0 else 's',ms=5 if j==0 else 4.3,
    mfc=c if j==0 else 'white',mec=c,ecolor=c,lw=1.5 if j==0 else 1.1,capsize=2)
  a.text(.30,yy,f'P = {r.P:.4f}',va='center',fontsize=6.5)
 a.axvspan(-.004,.004,color='#F1F1F1',zorder=-2);zero(a,'v');a.set_xlim(-.055,.46);a.set_xticks([0,.1,.2]);a.set_ylim(-.6,1.6)
 a.set_yticks([1,0],['Adjusted for\nbatch + ΔFD','Adjusted for batch + ΔFD\n+ pre-training mean FC']);a.tick_params(axis='y',length=0,pad=4)
 a.set_xlabel('High − low training ΔFC\n(Fisher z, 95% CI)',labelpad=3);source('Fig4d',t)
 a=tag(f.add_subplot(gs[2,0]),'e');title(f,gs[2,0],'e','Fixed ΔFC classifier performance');performance_bubble(a)
 a=tag(f.add_subplot(gs[2,1]),'f');title(f,gs[2,1],'f','Held-out batch 1 decision margins')
 stems(a,F.triad_margin,'Batch 2 → 1\nLow: 4/7, High: 3/3 (7/10 correct)')
 source('Fig4f',F.triad_margin.assign(anonymous_index=F.triad_margin.animal.map(F.DISPLAY)))
 save(f,'Fig4','abcdef')

def upset(f,spec):
 sub=spec.subgridspec(2,1,height_ratios=[1.35,1],hspace=.07)
 a=tag(f.add_subplot(sub[0]),'f');b=tag(f.add_subplot(sub[1],sharex=a),'f')
 order=PERF[PERF.scheme=='B2toB1'].sort_values('balanced_accuracy',ascending=False).connection.tolist()
 expected=['ACC–DMS','PrL–DLS','PrL–NAc','PrL–DMS','ACC–NAc','ACC–DLS']
 F.check('Six columns strictly ordered by descending cross-batch BA',order==expected)
 a.set_ylim(30,108);a.set_yticks([40,60,80,100]);a.set_ylabel('Balanced accuracy (%)',labelpad=3)
 a.grid(axis='y',color='#F0F0F0',lw=.6,zorder=0);a.axhline(50,color='#999999',lw=.7,ls='--');a.tick_params(axis='x',bottom=False,labelbottom=False)
 for j,e in enumerate(order):
  r=PERF[PERF.connection==e].set_index('scheme');v=100*r.loc['B2toB1','balanced_accuracy'];lo=100*r.loc['LOO','balanced_accuracy']
  a.bar(j,v,width=.56,color='#3E75A3',edgecolor='none',zorder=3)
  a.scatter(j,lo,s=22,fc='#263A4C',ec='white',lw=.85,zorder=5)
  a.annotate(f'{v:.1f}',xy=(j,max(v,lo)),xytext=(0,5.8),textcoords='offset points',ha='center',va='bottom',fontsize=7)
 nodes=['ACC','PrL','NAc','DMS','DLS']
 for yy in range(5):b.axhline(yy,color='#F4F4F4',lw=.5,zorder=1)
 for j,e in enumerate(order):
  b.scatter(np.full(5,j),range(4,-1,-1),s=80,c='#E4E4E4',edgecolors='none',zorder=2)
  yy=[4-nodes.index(n) for n in e.split('–')];b.plot([j,j],yy,color='#111111',lw=2.2,zorder=3)
  b.scatter([j,j],yy,s=85,c='#CE5D56',edgecolors='none',zorder=4)
  auc=PERF[(PERF.connection==e)&(PERF.scheme=='B2toB1')].auc.iloc[0]
  b.annotate(f'{auc:.3f}',xy=(j,0),xycoords=b.get_xaxis_transform(),xytext=(0,-17.5),textcoords='offset points',ha='center',va='top',fontsize=6,annotation_clip=False)
 b.annotate('AUC',xy=(-.78,0),xycoords=b.get_xaxis_transform(),xytext=(0,-17.5),textcoords='offset points',ha='right',va='top',fontsize=6,annotation_clip=False)
 b.set_ylim(-.65,4.65);b.set_yticks(range(4,-1,-1),nodes);b.tick_params(axis='y',length=0,pad=4)
 b.set_ylabel('Regions',labelpad=4);b.set_xlim(-.65,5.65);b.set_xticks(range(6),[f'#{i+1}' for i in range(6)])
 b.spines['left'].set_visible(False);b.spines['bottom'].set_color('#111111')
 hh=[Rectangle((0,0),1,1,fc='#3E75A3',ec='none',label='Bar: Batch 2→1 BA (%)'),Line2D([],[],marker='o',ls='',ms=3.7,mfc='#263A4C',mec='white',label='Point: LOO BA (%)')]
 b.legend(handles=hh,loc='upper center',bbox_to_anchor=(.46,-.48),fontsize=6,ncol=2,handlelength=1.0,handletextpad=.35,columnspacing=1,borderpad=.2)
 source('Fig5f',PERF.assign(model_id=PERF.connection.map({e:f'#{i+1}' for i,e in enumerate(order)})))
 source('Fig5f_membership',pd.DataFrame([dict(model=f'#{j+1}',connection=e,ROI=n,member=n in e.split('–')) for j,e in enumerate(order) for n in nodes]))

def fig5():
 f=canvas(195);key(f);gs=f.add_gridspec(3,2,height_ratios=[1,.95,1.25],left=.09,right=.96,bottom=.19,top=.94,hspace=.50,wspace=.36)
 title(f,gs[0,0],'a','Prefrontal–striatal comparison framework')
 a=tag(f.add_subplot(gs[0,0]),'a');brain(a,['ACC','PrL','NAc','DMS','DLS'],[e.replace('–','-') for e in CORE],True)
 a.text(.5,-.09,'2 prefrontal × 3 striatal ROIs · all 6 connections\nSolid: nominal P < 0.05; dashed: P ≥ 0.05',transform=a.transAxes,ha='center',va='top',fontsize=6)
 source('Fig5a',BASE)
 title(f,gs[0,1],'b','All six baseline group differences');a=tag(f.add_subplot(gs[0,1]),'b')
 p=a.get_position();a.set_position([p.x0+.045,p.y0,p.width-.045,p.height]);forest(a,BASE);source('Fig5b',BASE)
 title(f,gs[1,0],'c','Pre-training FC in the two earning groups')
 sub=gs[1,0].subgridspec(1,2,wspace=.35);t=F.baseline_data();lim=(t.FC.min()-.08*(t.FC.max()-t.FC.min()),t.FC.max()+.25*(t.FC.max()-t.FC.min()))
 for j,e in enumerate(['ACC–DMS','ACC–DLS']):
  a=tag(f.add_subplot(sub[j]),'c');r=BASE[BASE.connection==e].iloc[0]
  rain(a,t[t.connection==e],'FC',f'{e} (P = {r.P_wild:.4f})',True);a.set_ylim(*lim)
  if j==0:a.set_ylabel('Pre-training FC (Fisher z)',labelpad=3)
  else:a.tick_params(axis='y',labelleft=False)
 source('Fig5c',t)
 title(f,gs[1,1],'d','ACC–DMS classifier performance');a=tag(f.add_subplot(gs[1,1]),'d');performance_bubble(a,True)
 title(f,gs[2,0],'e','ACC–DMS held-out batch 1 decision margins');a=tag(f.add_subplot(gs[2,0]),'e')
 stems(a,F.baseline_margin,'Batch 2 → 1 · Low: 6/7, High: 3/3 (9/10 correct)')
 source('Fig5e',F.baseline_margin.assign(anonymous_index=F.baseline_margin.animal.map(F.DISPLAY)))
 title(f,gs[2,1],'f','All six fixed baseline classifiers');upset(f,gs[2,1])
 save(f,'Fig5','abcdef')

if __name__=='__main__':
 import sys
 verify_inputs()
 for name in sys.argv[1:] or ['Fig4','Fig5']:
  {'Fig4':fig4,'Fig5':fig5}[name]();print(name+' exported',flush=True)
 (HERE/'review/numerical_checks.json').write_text(json.dumps(F.checks,ensure_ascii=False,indent=2))
 (HERE/'review/text_bounds.json').write_text(json.dumps(AUDIT,ensure_ascii=False,indent=2))
 (HERE/'review/geometry_checks.json').write_text(json.dumps(GEOMETRY,ensure_ascii=False,indent=2))
 (HERE/'review/figure_metadata.json').write_text(json.dumps(META,ensure_ascii=False,indent=2))
 print('Checks passed:',len(F.checks),flush=True)
