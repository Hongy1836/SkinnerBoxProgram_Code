"""Atlas-derived sagittal projection with unchanged physical ROI centroids.
All anatomy is in the study template; header coordinates are inflated tenfold.
Contours project atlas labels over ML; labels move, centroid anchors do not.
"""
from style import *
import pandas as pd,nibabel as nib
from scipy.ndimage import gaussian_filter
from matplotlib.patches import PathPatch,FancyArrowPatch
from matplotlib.path import Path as MPath
ROOT=HERE.parents[2]
REF=HERE/'inputs/anatomy'
if not REF.exists():REF=HERE/'inputs/anatomy'
if not REF.exists():REF=ROOT/'AllSeeds/Seeds_Allen15_EPIfit_1002/reference'
NODES=['ACC','PrL','OrbB','NAc','DMS','DLS','M1','M2','S1','S2','AI','VTA','LHA']
MZ=np.load(HERE/'inputs/masks13.npz')
POS={n:nib.affines.apply_affine(MZ['affine'],np.argwhere(MZ[n])).mean(0)[1:]/10 for n in NODES}
COL={n:('#D8A770' if n in ['ACC','PrL','OrbB','AI'] else '#77AAA0' if n in ['M1','M2','S1','S2'] else '#8C83AC' if n in ['NAc','DMS','DLS'] else '#D6AE63') for n in NODES}
# Label positions are independent of the unchanged centroid anchors.
LAB={'OrbB':(5.4,1.45),'PrL':(4.4,3.55),'ACC':(.9,4.8),'M2':(3.0,4.8),'M1':(-.85,4.8),'S1':(-2.55,3.7),'S2':(-2.1,1.6),'DLS':(-.55,.65),'DMS':(4.0,.6),'AI':(3.8,-.65),'NAc':(2.7,-2.1),'LHA':(-.2,-2.4),'VTA':(-2.1,-2.0)}
CACHE=HERE/'inputs/atlas_projection_contours.npz'
if not CACHE.exists():
 im=nib.load(REF/'allen_annotation_EPIfit.nii.gz');raw=np.asarray(im.dataobj);vol=np.where(np.abs(raw-np.rint(raw))<1e-4,np.rint(raw),-1).astype(int)
 st=pd.read_csv(REF/'allen_structures.csv' if (REF/'allen_structures.csv').exists() else REF.parent/'code/allen_structures.csv')
 # The resampled annotation contains graph_order values, not ontology structure IDs.
 print('Atlas annotation value overlap:',len(set(np.unique(vol))&set(st.graph_order)),flush=True)
 arrays={}
 for name,sid in [('whole',None),('cerebellum',512),('striatum',477),('isocortex',315),('olfactory',507)]:
  ids=st.loc[st.structure_id_path.str.contains('/'+str(sid)+'/',regex=False),'graph_order'].to_numpy() if sid else []
  m=(raw>0) if sid is None else np.isin(vol,ids[ids>=0])
  proj=gaussian_filter(m.any(0).T.astype(float),1.2)
  x=(im.affine[1,3]+im.affine[1,1]*np.arange(vol.shape[1]))/10
  y=(im.affine[2,3]+im.affine[2,2]*np.arange(vol.shape[2]))/10
  f,a=plt.subplots();cs=a.contour(x,y,proj,levels=[.5])
  paths=cs.get_paths();ii=0
  for path in paths:
   # Split compound paths so each boundary remains a true vector.
   starts=np.flatnonzero(path.codes==MPath.MOVETO)
   for start,end in zip(starts,list(starts[1:])+[len(path.vertices)]):
    v=path.vertices[start:end]
    if len(v)>12:arrays[f'{name}_{ii}']=v;ii+=1
  plt.close(f)
 np.savez_compressed(CACHE,**arrays)
CON=np.load(CACHE)
source('Anatomical_centroids',pd.DataFrame([dict(ROI=n,anterior_coordinate_mm=POS[n][0],dorsal_coordinate_mm=POS[n][1],label_AP_mm=LAB[n][0],label_DV_mm=LAB[n][1],voxel_count=int(MZ[n].sum()),coordinate_frame='study-template; header affine divided by 10; not bregma') for n in NODES]))

def brain(ax,active=(),edges=(),all_nodes=False,hub=None,mini=False,edge_weights=None,signed=None,curve_radii=None):
 ax.axis('off');ax.set_aspect('equal');ax.set_xlim(7.1,-8.5);ax.set_ylim(-4.3,5.6)
 for name,fc,ec,lw,ls in [('whole','#F8F8F7','#8F9498',.65,'-'),('cerebellum','#ECEEED','#C2C5C4',.5,'--'),('isocortex','none','#D6D8D6',.4,'-'),('striatum','#ECEBEF','#C8C5D0',.45,'-'),('olfactory','none','#C8CBC8',.45,'-')]:
  for k in CON.files:
   if k.startswith(name+'_'):ax.add_patch(PathPatch(MPath(CON[k],closed=True),facecolor=fc,edgecolor=ec,lw=lw,ls=ls,zorder=0))
 if all_nodes:
  for n,p in POS.items():
   if n not in active:ax.scatter(*p,s=6,fc='#CBCBCB',ec='none',zorder=1)
 for i,e in enumerate(edges):
  a,b=e.split('-');col=HIGH;lw=1.3;ls='-'
  if signed is not None:
   r,pval=signed[e];col=(HIGH if r>0 else LOW) if pval<.05 else '#D0D0D0';lw=2.2 if pval<.05 else .8;ls='-' if pval<.05 else '--'
  if edge_weights is not None:lw=.8+1.5*edge_weights[e]/max(edge_weights.values())
  rad=(.10 if i%2==0 else -.14) if curve_radii is None else curve_radii[e]
  ax.add_patch(FancyArrowPatch(POS[a],POS[b],connectionstyle=f'arc3,rad={rad}',arrowstyle='-',lw=lw,color=col,ls=ls,zorder=2 if signed is None or signed[e][1]>=.05 else 3,shrinkA=0,shrinkB=0))
 for n in (NODES if all_nodes else active):
  p=POS[n];on=n in active;sz=10 if not mini else 7
  if n==hub:
   ax.scatter(*p,s=90,fc='none',ec=COL[n],lw=.6,alpha=.65,zorder=4);ax.scatter(*p,s=45,fc='none',ec=COL[n],lw=.8,zorder=4)
  ax.scatter(*p,s=sz if on else 5,fc=COL[n] if on else '#CCCCCC',ec=DARK if on else 'none',lw=.45,zorder=5)
  lp=LAB[n]
  ax.annotate(n,xy=p,xytext=lp,fontsize=6.5 if not mini else 6.5,ha='center',va='center',color=DARK if on else '#676767',bbox=dict(boxstyle='round,pad=0.13',fc=COL[n] if on else 'white',ec='none',alpha=.85 if on else .8),arrowprops=dict(arrowstyle='-',lw=.4,color='#666666',shrinkA=1,shrinkB=1),zorder=6)
 if not mini:
  ax.plot([4.4,3.4],[-3.35,-3.35],color=DARK,lw=1);ax.text(3.9,-3.75,'1 mm',fontsize=6.5,ha='center',va='center')
  x,y=-6.8,-2.6;d=.5
  ax.plot([x-d,x+d],[y,y],color=DARK,lw=.65);ax.plot([x,x],[y-d,y+d],color=DARK,lw=.65)
  for xx,yy,lab in [(x+d+.3,y,'A'),(x-d-.3,y,'P'),(x,y+d+.3,'D'),(x,y-d-.3,'V')]:ax.text(xx,yy,lab,ha='center',va='center',fontsize=6.5)
